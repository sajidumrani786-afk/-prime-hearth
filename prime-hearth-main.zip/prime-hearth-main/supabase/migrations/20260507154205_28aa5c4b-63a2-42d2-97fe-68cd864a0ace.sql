
-- =========================================================
-- ENUMS
-- =========================================================
CREATE TYPE public.app_role AS ENUM ('admin','accountant','sales_user','purchase_user','viewer');
CREATE TYPE public.account_type AS ENUM ('asset','liability','equity','income','expense');
CREATE TYPE public.doc_status AS ENUM ('draft','confirmed','partial','completed','cancelled');
CREATE TYPE public.party_type AS ENUM ('customer','supplier');
CREATE TYPE public.movement_type AS ENUM ('in','out','adjustment');
CREATE TYPE public.payment_direction AS ENUM ('received','paid');

-- =========================================================
-- PROFILES + ROLES
-- =========================================================
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text,
  email text,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, role)
);
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role);
$$;

CREATE OR REPLACE FUNCTION public.has_any_role(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id);
$$;

CREATE OR REPLACE FUNCTION public.is_staff(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id
    AND role IN ('admin','accountant','sales_user','purchase_user'));
$$;

-- Auto-create profile + assign first user as admin
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE user_count int;
BEGIN
  INSERT INTO public.profiles(id, full_name, email)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email), NEW.email);
  SELECT count(*) INTO user_count FROM auth.users;
  IF user_count = 1 THEN
    INSERT INTO public.user_roles(user_id, role) VALUES (NEW.id, 'admin');
  ELSE
    INSERT INTO public.user_roles(user_id, role) VALUES (NEW.id, 'viewer');
  END IF;
  RETURN NEW;
END;$$;

CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- =========================================================
-- COMPANY SETTINGS
-- =========================================================
CREATE TABLE public.company_settings (
  id int PRIMARY KEY DEFAULT 1,
  company_name text NOT NULL DEFAULT 'My Pharma Co.',
  currency_code text NOT NULL DEFAULT 'INR',
  currency_symbol text NOT NULL DEFAULT '₹',
  tax_mode text NOT NULL DEFAULT 'gst', -- gst|simple|none
  default_tax_rate numeric(6,3) NOT NULL DEFAULT 12.0,
  fiscal_year_start_month int NOT NULL DEFAULT 4,
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT one_row CHECK (id = 1)
);
INSERT INTO public.company_settings(id) VALUES (1);
ALTER TABLE public.company_settings ENABLE ROW LEVEL SECURITY;

-- =========================================================
-- CHART OF ACCOUNTS
-- =========================================================
CREATE TABLE public.accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  name text NOT NULL,
  type public.account_type NOT NULL,
  is_system boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.accounts ENABLE ROW LEVEL SECURITY;

INSERT INTO public.accounts(code,name,type,is_system) VALUES
('1000','Cash','asset',true),
('1010','Bank','asset',true),
('1100','Accounts Receivable','asset',true),
('1200','Inventory','asset',true),
('1300','Input Tax (GST)','asset',true),
('2000','Accounts Payable','liability',true),
('2100','Output Tax (GST)','liability',true),
('3000','Owner Equity','equity',true),
('4000','Sales Revenue','income',true),
('5000','Cost of Goods Sold','expense',true),
('5100','Purchase Discount','income',true),
('6000','Operating Expenses','expense',true);

-- =========================================================
-- MASTER DATA
-- =========================================================
CREATE TABLE public.product_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.product_categories ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.warehouses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  name text NOT NULL,
  address text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO public.warehouses(code,name) VALUES ('MAIN','Main Warehouse');
ALTER TABLE public.warehouses ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sku text UNIQUE NOT NULL,
  name text NOT NULL,
  category_id uuid REFERENCES public.product_categories(id) ON DELETE SET NULL,
  unit text NOT NULL DEFAULT 'PCS',
  hsn_code text,
  purchase_price numeric(14,2) NOT NULL DEFAULT 0,
  sale_price numeric(14,2) NOT NULL DEFAULT 0,
  tax_rate numeric(6,3) NOT NULL DEFAULT 12.0,
  reorder_level numeric(14,2) NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.suppliers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  name text NOT NULL,
  contact_person text,
  email text,
  phone text,
  address text,
  gstin text,
  opening_balance numeric(14,2) NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.suppliers ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  name text NOT NULL,
  contact_person text,
  email text,
  phone text,
  address text,
  gstin text,
  credit_limit numeric(14,2) NOT NULL DEFAULT 0,
  opening_balance numeric(14,2) NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;

-- =========================================================
-- INVENTORY MOVEMENTS
-- =========================================================
CREATE TABLE public.inventory_movements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES public.products(id),
  warehouse_id uuid NOT NULL REFERENCES public.warehouses(id),
  movement_type public.movement_type NOT NULL,
  qty numeric(14,3) NOT NULL,
  unit_cost numeric(14,4) NOT NULL DEFAULT 0,
  reference_type text,
  reference_id uuid,
  notes text,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_invmov_product ON public.inventory_movements(product_id);
CREATE INDEX idx_invmov_ref ON public.inventory_movements(reference_type, reference_id);
ALTER TABLE public.inventory_movements ENABLE ROW LEVEL SECURITY;

-- Stock view (signed)
CREATE OR REPLACE VIEW public.v_stock_balance AS
SELECT p.id AS product_id, p.sku, p.name, w.id AS warehouse_id, w.name AS warehouse_name,
  COALESCE(SUM(CASE m.movement_type WHEN 'in' THEN m.qty WHEN 'out' THEN -m.qty ELSE m.qty END),0) AS qty_on_hand,
  COALESCE(AVG(NULLIF(m.unit_cost,0)) FILTER (WHERE m.movement_type='in'),0) AS avg_cost
FROM public.products p
CROSS JOIN public.warehouses w
LEFT JOIN public.inventory_movements m ON m.product_id=p.id AND m.warehouse_id=w.id
GROUP BY p.id, p.sku, p.name, w.id, w.name;

-- =========================================================
-- JOURNAL ENTRIES
-- =========================================================
CREATE TABLE public.journal_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  entry_no text UNIQUE NOT NULL,
  entry_date date NOT NULL DEFAULT CURRENT_DATE,
  narration text,
  reference_type text,
  reference_id uuid,
  is_posted boolean NOT NULL DEFAULT true,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.journal_entries ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.journal_lines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  journal_id uuid NOT NULL REFERENCES public.journal_entries(id) ON DELETE CASCADE,
  account_id uuid NOT NULL REFERENCES public.accounts(id),
  party_type public.party_type,
  party_id uuid,
  debit numeric(14,2) NOT NULL DEFAULT 0,
  credit numeric(14,2) NOT NULL DEFAULT 0,
  description text,
  CONSTRAINT chk_debit_credit CHECK ((debit>=0 AND credit>=0) AND (debit=0 OR credit=0))
);
CREATE INDEX idx_jl_account ON public.journal_lines(account_id);
CREATE INDEX idx_jl_party ON public.journal_lines(party_type, party_id);
ALTER TABLE public.journal_lines ENABLE ROW LEVEL SECURITY;

-- Doc number sequences
CREATE TABLE public.doc_sequences (
  doc_type text PRIMARY KEY,
  prefix text NOT NULL,
  next_no int NOT NULL DEFAULT 1
);
INSERT INTO public.doc_sequences(doc_type,prefix) VALUES
 ('PO','PO-'),('GRN','GRN-'),('PI','PI-'),
 ('SO','SO-'),('DLV','DLV-'),('SI','SI-'),
 ('PAY','PAY-'),('JE','JE-');

CREATE OR REPLACE FUNCTION public.next_doc_no(_doc_type text)
RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE p text; n int;
BEGIN
  UPDATE public.doc_sequences SET next_no = next_no + 1
  WHERE doc_type = _doc_type
  RETURNING prefix, next_no - 1 INTO p, n;
  RETURN p || lpad(n::text, 6, '0');
END;$$;

-- =========================================================
-- PURCHASE
-- =========================================================
CREATE TABLE public.purchase_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  po_no text UNIQUE NOT NULL DEFAULT public.next_doc_no('PO'),
  supplier_id uuid NOT NULL REFERENCES public.suppliers(id),
  warehouse_id uuid NOT NULL REFERENCES public.warehouses(id),
  order_date date NOT NULL DEFAULT CURRENT_DATE,
  expected_date date,
  status public.doc_status NOT NULL DEFAULT 'draft',
  subtotal numeric(14,2) NOT NULL DEFAULT 0,
  tax_total numeric(14,2) NOT NULL DEFAULT 0,
  discount numeric(14,2) NOT NULL DEFAULT 0,
  total numeric(14,2) NOT NULL DEFAULT 0,
  notes text,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.purchase_order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  po_id uuid NOT NULL REFERENCES public.purchase_orders(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES public.products(id),
  qty numeric(14,3) NOT NULL,
  unit_price numeric(14,4) NOT NULL,
  tax_rate numeric(6,3) NOT NULL DEFAULT 0,
  line_total numeric(14,2) NOT NULL DEFAULT 0
);
ALTER TABLE public.purchase_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.purchase_order_items ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.goods_receipts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  grn_no text UNIQUE NOT NULL DEFAULT public.next_doc_no('GRN'),
  po_id uuid REFERENCES public.purchase_orders(id),
  supplier_id uuid NOT NULL REFERENCES public.suppliers(id),
  warehouse_id uuid NOT NULL REFERENCES public.warehouses(id),
  receipt_date date NOT NULL DEFAULT CURRENT_DATE,
  status public.doc_status NOT NULL DEFAULT 'completed',
  notes text,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.goods_receipt_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  grn_id uuid NOT NULL REFERENCES public.goods_receipts(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES public.products(id),
  qty numeric(14,3) NOT NULL,
  unit_cost numeric(14,4) NOT NULL DEFAULT 0
);
ALTER TABLE public.goods_receipts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.goods_receipt_items ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.purchase_invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pi_no text UNIQUE NOT NULL DEFAULT public.next_doc_no('PI'),
  supplier_id uuid NOT NULL REFERENCES public.suppliers(id),
  po_id uuid REFERENCES public.purchase_orders(id),
  grn_id uuid REFERENCES public.goods_receipts(id),
  invoice_date date NOT NULL DEFAULT CURRENT_DATE,
  due_date date,
  subtotal numeric(14,2) NOT NULL DEFAULT 0,
  tax_total numeric(14,2) NOT NULL DEFAULT 0,
  discount numeric(14,2) NOT NULL DEFAULT 0,
  total numeric(14,2) NOT NULL DEFAULT 0,
  paid_amount numeric(14,2) NOT NULL DEFAULT 0,
  status public.doc_status NOT NULL DEFAULT 'confirmed',
  notes text,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.purchase_invoice_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pi_id uuid NOT NULL REFERENCES public.purchase_invoices(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES public.products(id),
  qty numeric(14,3) NOT NULL,
  unit_price numeric(14,4) NOT NULL,
  tax_rate numeric(6,3) NOT NULL DEFAULT 0,
  line_total numeric(14,2) NOT NULL DEFAULT 0
);
ALTER TABLE public.purchase_invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.purchase_invoice_items ENABLE ROW LEVEL SECURITY;

-- =========================================================
-- SALES
-- =========================================================
CREATE TABLE public.sales_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  so_no text UNIQUE NOT NULL DEFAULT public.next_doc_no('SO'),
  customer_id uuid NOT NULL REFERENCES public.customers(id),
  warehouse_id uuid NOT NULL REFERENCES public.warehouses(id),
  order_date date NOT NULL DEFAULT CURRENT_DATE,
  delivery_date date,
  status public.doc_status NOT NULL DEFAULT 'draft',
  subtotal numeric(14,2) NOT NULL DEFAULT 0,
  tax_total numeric(14,2) NOT NULL DEFAULT 0,
  discount numeric(14,2) NOT NULL DEFAULT 0,
  total numeric(14,2) NOT NULL DEFAULT 0,
  notes text,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.sales_order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  so_id uuid NOT NULL REFERENCES public.sales_orders(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES public.products(id),
  qty numeric(14,3) NOT NULL,
  unit_price numeric(14,4) NOT NULL,
  tax_rate numeric(6,3) NOT NULL DEFAULT 0,
  line_total numeric(14,2) NOT NULL DEFAULT 0
);
ALTER TABLE public.sales_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sales_order_items ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.deliveries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  dlv_no text UNIQUE NOT NULL DEFAULT public.next_doc_no('DLV'),
  so_id uuid REFERENCES public.sales_orders(id),
  customer_id uuid NOT NULL REFERENCES public.customers(id),
  warehouse_id uuid NOT NULL REFERENCES public.warehouses(id),
  delivery_date date NOT NULL DEFAULT CURRENT_DATE,
  status public.doc_status NOT NULL DEFAULT 'completed',
  notes text,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.delivery_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  delivery_id uuid NOT NULL REFERENCES public.deliveries(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES public.products(id),
  qty numeric(14,3) NOT NULL,
  unit_cost numeric(14,4) NOT NULL DEFAULT 0
);
ALTER TABLE public.deliveries ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.delivery_items ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.sales_invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  si_no text UNIQUE NOT NULL DEFAULT public.next_doc_no('SI'),
  customer_id uuid NOT NULL REFERENCES public.customers(id),
  so_id uuid REFERENCES public.sales_orders(id),
  delivery_id uuid REFERENCES public.deliveries(id),
  invoice_date date NOT NULL DEFAULT CURRENT_DATE,
  due_date date,
  subtotal numeric(14,2) NOT NULL DEFAULT 0,
  tax_total numeric(14,2) NOT NULL DEFAULT 0,
  discount numeric(14,2) NOT NULL DEFAULT 0,
  total numeric(14,2) NOT NULL DEFAULT 0,
  paid_amount numeric(14,2) NOT NULL DEFAULT 0,
  status public.doc_status NOT NULL DEFAULT 'confirmed',
  notes text,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.sales_invoice_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  si_id uuid NOT NULL REFERENCES public.sales_invoices(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES public.products(id),
  qty numeric(14,3) NOT NULL,
  unit_price numeric(14,4) NOT NULL,
  tax_rate numeric(6,3) NOT NULL DEFAULT 0,
  line_total numeric(14,2) NOT NULL DEFAULT 0
);
ALTER TABLE public.sales_invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sales_invoice_items ENABLE ROW LEVEL SECURITY;

-- =========================================================
-- PAYMENTS
-- =========================================================
CREATE TABLE public.payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pay_no text UNIQUE NOT NULL DEFAULT public.next_doc_no('PAY'),
  direction public.payment_direction NOT NULL, -- received from customer | paid to supplier
  party_type public.party_type NOT NULL,
  party_id uuid NOT NULL,
  invoice_id uuid, -- pi or si
  payment_date date NOT NULL DEFAULT CURRENT_DATE,
  amount numeric(14,2) NOT NULL,
  method text NOT NULL DEFAULT 'cash', -- cash|bank
  account_id uuid REFERENCES public.accounts(id), -- cash/bank account
  notes text,
  created_by uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;

-- =========================================================
-- HELPER: post journal entry
-- =========================================================
CREATE OR REPLACE FUNCTION public.post_journal(
  _date date, _narration text, _ref_type text, _ref_id uuid, _lines jsonb
) RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE je_id uuid; ln jsonb; total_d numeric:=0; total_c numeric:=0;
BEGIN
  INSERT INTO public.journal_entries(entry_no, entry_date, narration, reference_type, reference_id, created_by)
  VALUES (public.next_doc_no('JE'), _date, _narration, _ref_type, _ref_id, auth.uid())
  RETURNING id INTO je_id;

  FOR ln IN SELECT * FROM jsonb_array_elements(_lines) LOOP
    INSERT INTO public.journal_lines(journal_id, account_id, party_type, party_id, debit, credit, description)
    VALUES (
      je_id,
      (ln->>'account_id')::uuid,
      NULLIF(ln->>'party_type','')::public.party_type,
      NULLIF(ln->>'party_id','')::uuid,
      COALESCE((ln->>'debit')::numeric,0),
      COALESCE((ln->>'credit')::numeric,0),
      ln->>'description'
    );
    total_d := total_d + COALESCE((ln->>'debit')::numeric,0);
    total_c := total_c + COALESCE((ln->>'credit')::numeric,0);
  END LOOP;

  IF round(total_d,2) <> round(total_c,2) THEN
    RAISE EXCEPTION 'Journal not balanced: debit=% credit=%', total_d, total_c;
  END IF;
  RETURN je_id;
END;$$;

CREATE OR REPLACE FUNCTION public.account_id_by_code(_code text)
RETURNS uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path=public AS $$
  SELECT id FROM public.accounts WHERE code=_code LIMIT 1;
$$;

-- =========================================================
-- TRIGGERS: auto stock + auto journal
-- =========================================================
-- GRN -> stock IN
CREATE OR REPLACE FUNCTION public.grn_after_insert()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE r record;
BEGIN
  FOR r IN SELECT i.*, g.warehouse_id FROM public.goods_receipt_items i
           JOIN public.goods_receipts g ON g.id=i.grn_id WHERE i.grn_id = NEW.grn_id LOOP
    INSERT INTO public.inventory_movements(product_id,warehouse_id,movement_type,qty,unit_cost,reference_type,reference_id,created_by)
    VALUES (r.product_id, r.warehouse_id, 'in', r.qty, r.unit_cost, 'grn', NEW.grn_id, auth.uid());
  END LOOP;
  RETURN NEW;
END;$$;

-- We trigger per-grn, only once per grn. Use AFTER INSERT on goods_receipts itself? Items inserted after.
-- Better: trigger when status confirmed - we'll do trigger on grn_items AFTER INSERT to add per-line movement
CREATE OR REPLACE FUNCTION public.grn_item_after_insert()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE wh uuid;
BEGIN
  SELECT warehouse_id INTO wh FROM public.goods_receipts WHERE id=NEW.grn_id;
  INSERT INTO public.inventory_movements(product_id,warehouse_id,movement_type,qty,unit_cost,reference_type,reference_id,created_by)
  VALUES (NEW.product_id, wh, 'in', NEW.qty, NEW.unit_cost, 'grn', NEW.grn_id, auth.uid());
  RETURN NEW;
END;$$;
CREATE TRIGGER trg_grn_item_ai AFTER INSERT ON public.goods_receipt_items
FOR EACH ROW EXECUTE FUNCTION public.grn_item_after_insert();

-- Delivery item -> stock OUT + capture cost
CREATE OR REPLACE FUNCTION public.delivery_item_after_insert()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE wh uuid; avg_cost numeric;
BEGIN
  SELECT warehouse_id INTO wh FROM public.deliveries WHERE id=NEW.delivery_id;
  SELECT COALESCE(AVG(NULLIF(unit_cost,0)),0) INTO avg_cost
   FROM public.inventory_movements WHERE product_id=NEW.product_id AND movement_type='in';
  IF NEW.unit_cost = 0 THEN
    UPDATE public.delivery_items SET unit_cost = avg_cost WHERE id = NEW.id;
  END IF;
  INSERT INTO public.inventory_movements(product_id,warehouse_id,movement_type,qty,unit_cost,reference_type,reference_id,created_by)
  VALUES (NEW.product_id, wh, 'out', NEW.qty, COALESCE(NULLIF(NEW.unit_cost,0), avg_cost), 'delivery', NEW.delivery_id, auth.uid());
  RETURN NEW;
END;$$;
CREATE TRIGGER trg_delivery_item_ai AFTER INSERT ON public.delivery_items
FOR EACH ROW EXECUTE FUNCTION public.delivery_item_after_insert();

-- Purchase Invoice -> Journal: Dr Inventory + Dr Input Tax / Cr AP
CREATE OR REPLACE FUNCTION public.pi_after_insert()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE lines jsonb;
BEGIN
  -- defer to after items inserted: we'll fire after lines exist via separate function
  RETURN NEW;
END;$$;

-- Function called from app after creating PI + items
CREATE OR REPLACE FUNCTION public.finalize_purchase_invoice(_pi_id uuid)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE pi record; lines jsonb := '[]'::jsonb; je uuid;
BEGIN
  SELECT * INTO pi FROM public.purchase_invoices WHERE id=_pi_id;
  IF pi IS NULL THEN RAISE EXCEPTION 'PI not found'; END IF;

  -- recalc totals
  UPDATE public.purchase_invoices SET
    subtotal = COALESCE((SELECT SUM(qty*unit_price) FROM public.purchase_invoice_items WHERE pi_id=_pi_id),0),
    tax_total = COALESCE((SELECT SUM(qty*unit_price*tax_rate/100.0) FROM public.purchase_invoice_items WHERE pi_id=_pi_id),0)
  WHERE id=_pi_id;
  UPDATE public.purchase_invoices SET total = subtotal + tax_total - discount WHERE id=_pi_id;
  SELECT * INTO pi FROM public.purchase_invoices WHERE id=_pi_id;

  lines := jsonb_build_array(
    jsonb_build_object('account_id', public.account_id_by_code('1200'), 'debit', pi.subtotal, 'credit', 0, 'description','Inventory'),
    jsonb_build_object('account_id', public.account_id_by_code('1300'), 'debit', pi.tax_total, 'credit', 0, 'description','Input Tax'),
    jsonb_build_object('account_id', public.account_id_by_code('2000'),
       'party_type','supplier','party_id', pi.supplier_id::text,
       'debit', 0, 'credit', pi.total, 'description','AP for PI '||pi.pi_no)
  );
  je := public.post_journal(pi.invoice_date, 'Purchase Invoice '||pi.pi_no, 'purchase_invoice', _pi_id, lines);
  RETURN je;
END;$$;

-- Sales Invoice -> Journal: Dr AR / Cr Sales + Cr Output Tax
CREATE OR REPLACE FUNCTION public.finalize_sales_invoice(_si_id uuid)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE si record; lines jsonb; cogs numeric:=0; je uuid; r record;
BEGIN
  SELECT * INTO si FROM public.sales_invoices WHERE id=_si_id;
  IF si IS NULL THEN RAISE EXCEPTION 'SI not found'; END IF;

  UPDATE public.sales_invoices SET
    subtotal = COALESCE((SELECT SUM(qty*unit_price) FROM public.sales_invoice_items WHERE si_id=_si_id),0),
    tax_total = COALESCE((SELECT SUM(qty*unit_price*tax_rate/100.0) FROM public.sales_invoice_items WHERE si_id=_si_id),0)
  WHERE id=_si_id;
  UPDATE public.sales_invoices SET total = subtotal + tax_total - discount WHERE id=_si_id;
  SELECT * INTO si FROM public.sales_invoices WHERE id=_si_id;

  lines := jsonb_build_array(
    jsonb_build_object('account_id', public.account_id_by_code('1100'),
       'party_type','customer','party_id', si.customer_id::text,
       'debit', si.total, 'credit', 0, 'description','AR for SI '||si.si_no),
    jsonb_build_object('account_id', public.account_id_by_code('4000'), 'debit', 0, 'credit', si.subtotal - si.discount, 'description','Sales'),
    jsonb_build_object('account_id', public.account_id_by_code('2100'), 'debit', 0, 'credit', si.tax_total, 'description','Output Tax')
  );
  je := public.post_journal(si.invoice_date, 'Sales Invoice '||si.si_no, 'sales_invoice', _si_id, lines);

  -- COGS from delivery (if linked)
  IF si.delivery_id IS NOT NULL THEN
    SELECT COALESCE(SUM(qty*unit_cost),0) INTO cogs FROM public.delivery_items WHERE delivery_id=si.delivery_id;
    IF cogs > 0 THEN
      PERFORM public.post_journal(si.invoice_date, 'COGS for SI '||si.si_no, 'sales_invoice_cogs', _si_id,
        jsonb_build_array(
          jsonb_build_object('account_id', public.account_id_by_code('5000'), 'debit', cogs, 'credit', 0, 'description','COGS'),
          jsonb_build_object('account_id', public.account_id_by_code('1200'), 'debit', 0, 'credit', cogs, 'description','Inventory out')
        ));
    END IF;
  END IF;
  RETURN je;
END;$$;

-- Payment -> Journal
CREATE OR REPLACE FUNCTION public.payment_after_insert()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE cash_acc uuid; ar_acc uuid; ap_acc uuid; lines jsonb;
BEGIN
  cash_acc := COALESCE(NEW.account_id,
    CASE WHEN NEW.method='bank' THEN public.account_id_by_code('1010') ELSE public.account_id_by_code('1000') END);
  ar_acc := public.account_id_by_code('1100');
  ap_acc := public.account_id_by_code('2000');

  IF NEW.direction = 'received' THEN
    -- Dr Cash, Cr AR(party=customer)
    lines := jsonb_build_array(
      jsonb_build_object('account_id', cash_acc, 'debit', NEW.amount, 'credit', 0, 'description','Receipt '||NEW.pay_no),
      jsonb_build_object('account_id', ar_acc, 'party_type','customer','party_id', NEW.party_id::text,
        'debit', 0, 'credit', NEW.amount, 'description','AR settle')
    );
    IF NEW.invoice_id IS NOT NULL THEN
      UPDATE public.sales_invoices SET paid_amount = paid_amount + NEW.amount WHERE id = NEW.invoice_id;
    END IF;
  ELSE
    -- paid: Dr AP(party=supplier), Cr Cash
    lines := jsonb_build_array(
      jsonb_build_object('account_id', ap_acc, 'party_type','supplier','party_id', NEW.party_id::text,
        'debit', NEW.amount, 'credit', 0, 'description','AP settle'),
      jsonb_build_object('account_id', cash_acc, 'debit', 0, 'credit', NEW.amount, 'description','Payment '||NEW.pay_no)
    );
    IF NEW.invoice_id IS NOT NULL THEN
      UPDATE public.purchase_invoices SET paid_amount = paid_amount + NEW.amount WHERE id = NEW.invoice_id;
    END IF;
  END IF;

  PERFORM public.post_journal(NEW.payment_date, 'Payment '||NEW.pay_no, 'payment', NEW.id, lines);
  RETURN NEW;
END;$$;
CREATE TRIGGER trg_payment_ai AFTER INSERT ON public.payments
FOR EACH ROW EXECUTE FUNCTION public.payment_after_insert();

-- =========================================================
-- RLS POLICIES (authenticated staff can read; admin/accountant can manage)
-- =========================================================
-- profiles
CREATE POLICY "view own profile" ON public.profiles FOR SELECT TO authenticated USING (auth.uid()=id OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "update own profile" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid()=id);

-- user_roles
CREATE POLICY "view roles self/admin" ON public.user_roles FOR SELECT TO authenticated USING (auth.uid()=user_id OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "admin manage roles" ON public.user_roles FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

-- Generic helper macro: apply to many tables
DO $$
DECLARE t text;
BEGIN
  FOR t IN SELECT unnest(ARRAY[
    'company_settings','accounts','product_categories','warehouses','products',
    'suppliers','customers','inventory_movements','journal_entries','journal_lines',
    'doc_sequences','purchase_orders','purchase_order_items','goods_receipts','goods_receipt_items',
    'purchase_invoices','purchase_invoice_items','sales_orders','sales_order_items',
    'deliveries','delivery_items','sales_invoices','sales_invoice_items','payments'
  ]) LOOP
    EXECUTE format('CREATE POLICY "staff read %1$s" ON public.%1$I FOR SELECT TO authenticated USING (public.has_any_role(auth.uid()))', t);
    EXECUTE format('CREATE POLICY "staff write %1$s" ON public.%1$I FOR INSERT TO authenticated WITH CHECK (public.is_staff(auth.uid()))', t);
    EXECUTE format('CREATE POLICY "staff update %1$s" ON public.%1$I FOR UPDATE TO authenticated USING (public.is_staff(auth.uid())) WITH CHECK (public.is_staff(auth.uid()))', t);
    EXECUTE format('CREATE POLICY "admin delete %1$s" ON public.%1$I FOR DELETE TO authenticated USING (public.has_role(auth.uid(),''admin''))', t);
  END LOOP;
END$$;
