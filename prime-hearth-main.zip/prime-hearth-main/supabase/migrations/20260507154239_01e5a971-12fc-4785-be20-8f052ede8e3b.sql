
ALTER TABLE public.doc_sequences ENABLE ROW LEVEL SECURITY;
ALTER VIEW public.v_stock_balance SET (security_invoker = on);

REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.has_any_role(uuid) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.is_staff(uuid) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.next_doc_no(text) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.account_id_by_code(text) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.post_journal(date,text,text,uuid,jsonb) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.finalize_purchase_invoice(uuid) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.finalize_sales_invoice(uuid) FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.grn_after_insert() FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.grn_item_after_insert() FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.delivery_item_after_insert() FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.pi_after_insert() FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.payment_after_insert() FROM anon, public;

GRANT EXECUTE ON FUNCTION public.finalize_purchase_invoice(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.finalize_sales_invoice(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.next_doc_no(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.account_id_by_code(text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_any_role(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_staff(uuid) TO authenticated;
