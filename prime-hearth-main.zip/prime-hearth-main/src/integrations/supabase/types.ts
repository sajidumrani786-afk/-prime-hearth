export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      accounts: {
        Row: {
          code: string
          created_at: string
          id: string
          is_system: boolean
          name: string
          type: Database["public"]["Enums"]["account_type"]
        }
        Insert: {
          code: string
          created_at?: string
          id?: string
          is_system?: boolean
          name: string
          type: Database["public"]["Enums"]["account_type"]
        }
        Update: {
          code?: string
          created_at?: string
          id?: string
          is_system?: boolean
          name?: string
          type?: Database["public"]["Enums"]["account_type"]
        }
        Relationships: []
      }
      company_settings: {
        Row: {
          company_name: string
          currency_code: string
          currency_symbol: string
          default_tax_rate: number
          fiscal_year_start_month: number
          id: number
          tax_mode: string
          updated_at: string
        }
        Insert: {
          company_name?: string
          currency_code?: string
          currency_symbol?: string
          default_tax_rate?: number
          fiscal_year_start_month?: number
          id?: number
          tax_mode?: string
          updated_at?: string
        }
        Update: {
          company_name?: string
          currency_code?: string
          currency_symbol?: string
          default_tax_rate?: number
          fiscal_year_start_month?: number
          id?: number
          tax_mode?: string
          updated_at?: string
        }
        Relationships: []
      }
      customers: {
        Row: {
          address: string | null
          code: string
          contact_person: string | null
          created_at: string
          credit_limit: number
          email: string | null
          gstin: string | null
          id: string
          is_active: boolean
          name: string
          opening_balance: number
          phone: string | null
        }
        Insert: {
          address?: string | null
          code: string
          contact_person?: string | null
          created_at?: string
          credit_limit?: number
          email?: string | null
          gstin?: string | null
          id?: string
          is_active?: boolean
          name: string
          opening_balance?: number
          phone?: string | null
        }
        Update: {
          address?: string | null
          code?: string
          contact_person?: string | null
          created_at?: string
          credit_limit?: number
          email?: string | null
          gstin?: string | null
          id?: string
          is_active?: boolean
          name?: string
          opening_balance?: number
          phone?: string | null
        }
        Relationships: []
      }
      deliveries: {
        Row: {
          created_at: string
          created_by: string | null
          customer_id: string
          delivery_date: string
          dlv_no: string
          id: string
          notes: string | null
          so_id: string | null
          status: Database["public"]["Enums"]["doc_status"]
          warehouse_id: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          customer_id: string
          delivery_date?: string
          dlv_no?: string
          id?: string
          notes?: string | null
          so_id?: string | null
          status?: Database["public"]["Enums"]["doc_status"]
          warehouse_id: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          customer_id?: string
          delivery_date?: string
          dlv_no?: string
          id?: string
          notes?: string | null
          so_id?: string | null
          status?: Database["public"]["Enums"]["doc_status"]
          warehouse_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "deliveries_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deliveries_so_id_fkey"
            columns: ["so_id"]
            isOneToOne: false
            referencedRelation: "sales_orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deliveries_warehouse_id_fkey"
            columns: ["warehouse_id"]
            isOneToOne: false
            referencedRelation: "v_stock_balance"
            referencedColumns: ["warehouse_id"]
          },
          {
            foreignKeyName: "deliveries_warehouse_id_fkey"
            columns: ["warehouse_id"]
            isOneToOne: false
            referencedRelation: "warehouses"
            referencedColumns: ["id"]
          },
        ]
      }
      delivery_items: {
        Row: {
          delivery_id: string
          id: string
          product_id: string
          qty: number
          unit_cost: number
        }
        Insert: {
          delivery_id: string
          id?: string
          product_id: string
          qty: number
          unit_cost?: number
        }
        Update: {
          delivery_id?: string
          id?: string
          product_id?: string
          qty?: number
          unit_cost?: number
        }
        Relationships: [
          {
            foreignKeyName: "delivery_items_delivery_id_fkey"
            columns: ["delivery_id"]
            isOneToOne: false
            referencedRelation: "deliveries"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "delivery_items_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "delivery_items_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "v_stock_balance"
            referencedColumns: ["product_id"]
          },
        ]
      }
      doc_sequences: {
        Row: {
          doc_type: string
          next_no: number
          prefix: string
        }
        Insert: {
          doc_type: string
          next_no?: number
          prefix: string
        }
        Update: {
          doc_type?: string
          next_no?: number
          prefix?: string
        }
        Relationships: []
      }
      goods_receipt_items: {
        Row: {
          grn_id: string
          id: string
          product_id: string
          qty: number
          unit_cost: number
        }
        Insert: {
          grn_id: string
          id?: string
          product_id: string
          qty: number
          unit_cost?: number
        }
        Update: {
          grn_id?: string
          id?: string
          product_id?: string
          qty?: number
          unit_cost?: number
        }
        Relationships: [
          {
            foreignKeyName: "goods_receipt_items_grn_id_fkey"
            columns: ["grn_id"]
            isOneToOne: false
            referencedRelation: "goods_receipts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "goods_receipt_items_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "goods_receipt_items_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "v_stock_balance"
            referencedColumns: ["product_id"]
          },
        ]
      }
      goods_receipts: {
        Row: {
          created_at: string
          created_by: string | null
          grn_no: string
          id: string
          notes: string | null
          po_id: string | null
          receipt_date: string
          status: Database["public"]["Enums"]["doc_status"]
          supplier_id: string
          warehouse_id: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          grn_no?: string
          id?: string
          notes?: string | null
          po_id?: string | null
          receipt_date?: string
          status?: Database["public"]["Enums"]["doc_status"]
          supplier_id: string
          warehouse_id: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          grn_no?: string
          id?: string
          notes?: string | null
          po_id?: string | null
          receipt_date?: string
          status?: Database["public"]["Enums"]["doc_status"]
          supplier_id?: string
          warehouse_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "goods_receipts_po_id_fkey"
            columns: ["po_id"]
            isOneToOne: false
            referencedRelation: "purchase_orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "goods_receipts_supplier_id_fkey"
            columns: ["supplier_id"]
            isOneToOne: false
            referencedRelation: "suppliers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "goods_receipts_warehouse_id_fkey"
            columns: ["warehouse_id"]
            isOneToOne: false
            referencedRelation: "v_stock_balance"
            referencedColumns: ["warehouse_id"]
          },
          {
            foreignKeyName: "goods_receipts_warehouse_id_fkey"
            columns: ["warehouse_id"]
            isOneToOne: false
            referencedRelation: "warehouses"
            referencedColumns: ["id"]
          },
        ]
      }
      inventory_movements: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          movement_type: Database["public"]["Enums"]["movement_type"]
          notes: string | null
          product_id: string
          qty: number
          reference_id: string | null
          reference_type: string | null
          unit_cost: number
          warehouse_id: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          movement_type: Database["public"]["Enums"]["movement_type"]
          notes?: string | null
          product_id: string
          qty: number
          reference_id?: string | null
          reference_type?: string | null
          unit_cost?: number
          warehouse_id: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          movement_type?: Database["public"]["Enums"]["movement_type"]
          notes?: string | null
          product_id?: string
          qty?: number
          reference_id?: string | null
          reference_type?: string | null
          unit_cost?: number
          warehouse_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "inventory_movements_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "inventory_movements_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "v_stock_balance"
            referencedColumns: ["product_id"]
          },
          {
            foreignKeyName: "inventory_movements_warehouse_id_fkey"
            columns: ["warehouse_id"]
            isOneToOne: false
            referencedRelation: "v_stock_balance"
            referencedColumns: ["warehouse_id"]
          },
          {
            foreignKeyName: "inventory_movements_warehouse_id_fkey"
            columns: ["warehouse_id"]
            isOneToOne: false
            referencedRelation: "warehouses"
            referencedColumns: ["id"]
          },
        ]
      }
      journal_entries: {
        Row: {
          created_at: string
          created_by: string | null
          entry_date: string
          entry_no: string
          id: string
          is_posted: boolean
          narration: string | null
          reference_id: string | null
          reference_type: string | null
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          entry_date?: string
          entry_no: string
          id?: string
          is_posted?: boolean
          narration?: string | null
          reference_id?: string | null
          reference_type?: string | null
        }
        Update: {
          created_at?: string
          created_by?: string | null
          entry_date?: string
          entry_no?: string
          id?: string
          is_posted?: boolean
          narration?: string | null
          reference_id?: string | null
          reference_type?: string | null
        }
        Relationships: []
      }
      journal_lines: {
        Row: {
          account_id: string
          credit: number
          debit: number
          description: string | null
          id: string
          journal_id: string
          party_id: string | null
          party_type: Database["public"]["Enums"]["party_type"] | null
        }
        Insert: {
          account_id: string
          credit?: number
          debit?: number
          description?: string | null
          id?: string
          journal_id: string
          party_id?: string | null
          party_type?: Database["public"]["Enums"]["party_type"] | null
        }
        Update: {
          account_id?: string
          credit?: number
          debit?: number
          description?: string | null
          id?: string
          journal_id?: string
          party_id?: string | null
          party_type?: Database["public"]["Enums"]["party_type"] | null
        }
        Relationships: [
          {
            foreignKeyName: "journal_lines_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "journal_lines_journal_id_fkey"
            columns: ["journal_id"]
            isOneToOne: false
            referencedRelation: "journal_entries"
            referencedColumns: ["id"]
          },
        ]
      }
      payments: {
        Row: {
          account_id: string | null
          amount: number
          created_at: string
          created_by: string | null
          direction: Database["public"]["Enums"]["payment_direction"]
          id: string
          invoice_id: string | null
          method: string
          notes: string | null
          party_id: string
          party_type: Database["public"]["Enums"]["party_type"]
          pay_no: string
          payment_date: string
        }
        Insert: {
          account_id?: string | null
          amount: number
          created_at?: string
          created_by?: string | null
          direction: Database["public"]["Enums"]["payment_direction"]
          id?: string
          invoice_id?: string | null
          method?: string
          notes?: string | null
          party_id: string
          party_type: Database["public"]["Enums"]["party_type"]
          pay_no?: string
          payment_date?: string
        }
        Update: {
          account_id?: string | null
          amount?: number
          created_at?: string
          created_by?: string | null
          direction?: Database["public"]["Enums"]["payment_direction"]
          id?: string
          invoice_id?: string | null
          method?: string
          notes?: string | null
          party_id?: string
          party_type?: Database["public"]["Enums"]["party_type"]
          pay_no?: string
          payment_date?: string
        }
        Relationships: [
          {
            foreignKeyName: "payments_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "accounts"
            referencedColumns: ["id"]
          },
        ]
      }
      product_categories: {
        Row: {
          created_at: string
          id: string
          name: string
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
        }
        Relationships: []
      }
      products: {
        Row: {
          category_id: string | null
          created_at: string
          hsn_code: string | null
          id: string
          is_active: boolean
          name: string
          purchase_price: number
          reorder_level: number
          sale_price: number
          sku: string
          tax_rate: number
          unit: string
        }
        Insert: {
          category_id?: string | null
          created_at?: string
          hsn_code?: string | null
          id?: string
          is_active?: boolean
          name: string
          purchase_price?: number
          reorder_level?: number
          sale_price?: number
          sku: string
          tax_rate?: number
          unit?: string
        }
        Update: {
          category_id?: string | null
          created_at?: string
          hsn_code?: string | null
          id?: string
          is_active?: boolean
          name?: string
          purchase_price?: number
          reorder_level?: number
          sale_price?: number
          sku?: string
          tax_rate?: number
          unit?: string
        }
        Relationships: [
          {
            foreignKeyName: "products_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "product_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          created_at: string
          email: string | null
          full_name: string | null
          id: string
        }
        Insert: {
          created_at?: string
          email?: string | null
          full_name?: string | null
          id: string
        }
        Update: {
          created_at?: string
          email?: string | null
          full_name?: string | null
          id?: string
        }
        Relationships: []
      }
      purchase_invoice_items: {
        Row: {
          id: string
          line_total: number
          pi_id: string
          product_id: string
          qty: number
          tax_rate: number
          unit_price: number
        }
        Insert: {
          id?: string
          line_total?: number
          pi_id: string
          product_id: string
          qty: number
          tax_rate?: number
          unit_price: number
        }
        Update: {
          id?: string
          line_total?: number
          pi_id?: string
          product_id?: string
          qty?: number
          tax_rate?: number
          unit_price?: number
        }
        Relationships: [
          {
            foreignKeyName: "purchase_invoice_items_pi_id_fkey"
            columns: ["pi_id"]
            isOneToOne: false
            referencedRelation: "purchase_invoices"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "purchase_invoice_items_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "purchase_invoice_items_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "v_stock_balance"
            referencedColumns: ["product_id"]
          },
        ]
      }
      purchase_invoices: {
        Row: {
          created_at: string
          created_by: string | null
          discount: number
          due_date: string | null
          grn_id: string | null
          id: string
          invoice_date: string
          notes: string | null
          paid_amount: number
          pi_no: string
          po_id: string | null
          status: Database["public"]["Enums"]["doc_status"]
          subtotal: number
          supplier_id: string
          tax_total: number
          total: number
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          discount?: number
          due_date?: string | null
          grn_id?: string | null
          id?: string
          invoice_date?: string
          notes?: string | null
          paid_amount?: number
          pi_no?: string
          po_id?: string | null
          status?: Database["public"]["Enums"]["doc_status"]
          subtotal?: number
          supplier_id: string
          tax_total?: number
          total?: number
        }
        Update: {
          created_at?: string
          created_by?: string | null
          discount?: number
          due_date?: string | null
          grn_id?: string | null
          id?: string
          invoice_date?: string
          notes?: string | null
          paid_amount?: number
          pi_no?: string
          po_id?: string | null
          status?: Database["public"]["Enums"]["doc_status"]
          subtotal?: number
          supplier_id?: string
          tax_total?: number
          total?: number
        }
        Relationships: [
          {
            foreignKeyName: "purchase_invoices_grn_id_fkey"
            columns: ["grn_id"]
            isOneToOne: false
            referencedRelation: "goods_receipts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "purchase_invoices_po_id_fkey"
            columns: ["po_id"]
            isOneToOne: false
            referencedRelation: "purchase_orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "purchase_invoices_supplier_id_fkey"
            columns: ["supplier_id"]
            isOneToOne: false
            referencedRelation: "suppliers"
            referencedColumns: ["id"]
          },
        ]
      }
      purchase_order_items: {
        Row: {
          id: string
          line_total: number
          po_id: string
          product_id: string
          qty: number
          tax_rate: number
          unit_price: number
        }
        Insert: {
          id?: string
          line_total?: number
          po_id: string
          product_id: string
          qty: number
          tax_rate?: number
          unit_price: number
        }
        Update: {
          id?: string
          line_total?: number
          po_id?: string
          product_id?: string
          qty?: number
          tax_rate?: number
          unit_price?: number
        }
        Relationships: [
          {
            foreignKeyName: "purchase_order_items_po_id_fkey"
            columns: ["po_id"]
            isOneToOne: false
            referencedRelation: "purchase_orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "purchase_order_items_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "purchase_order_items_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "v_stock_balance"
            referencedColumns: ["product_id"]
          },
        ]
      }
      purchase_orders: {
        Row: {
          created_at: string
          created_by: string | null
          discount: number
          expected_date: string | null
          id: string
          notes: string | null
          order_date: string
          po_no: string
          status: Database["public"]["Enums"]["doc_status"]
          subtotal: number
          supplier_id: string
          tax_total: number
          total: number
          warehouse_id: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          discount?: number
          expected_date?: string | null
          id?: string
          notes?: string | null
          order_date?: string
          po_no?: string
          status?: Database["public"]["Enums"]["doc_status"]
          subtotal?: number
          supplier_id: string
          tax_total?: number
          total?: number
          warehouse_id: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          discount?: number
          expected_date?: string | null
          id?: string
          notes?: string | null
          order_date?: string
          po_no?: string
          status?: Database["public"]["Enums"]["doc_status"]
          subtotal?: number
          supplier_id?: string
          tax_total?: number
          total?: number
          warehouse_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "purchase_orders_supplier_id_fkey"
            columns: ["supplier_id"]
            isOneToOne: false
            referencedRelation: "suppliers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "purchase_orders_warehouse_id_fkey"
            columns: ["warehouse_id"]
            isOneToOne: false
            referencedRelation: "v_stock_balance"
            referencedColumns: ["warehouse_id"]
          },
          {
            foreignKeyName: "purchase_orders_warehouse_id_fkey"
            columns: ["warehouse_id"]
            isOneToOne: false
            referencedRelation: "warehouses"
            referencedColumns: ["id"]
          },
        ]
      }
      sales_invoice_items: {
        Row: {
          id: string
          line_total: number
          product_id: string
          qty: number
          si_id: string
          tax_rate: number
          unit_price: number
        }
        Insert: {
          id?: string
          line_total?: number
          product_id: string
          qty: number
          si_id: string
          tax_rate?: number
          unit_price: number
        }
        Update: {
          id?: string
          line_total?: number
          product_id?: string
          qty?: number
          si_id?: string
          tax_rate?: number
          unit_price?: number
        }
        Relationships: [
          {
            foreignKeyName: "sales_invoice_items_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sales_invoice_items_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "v_stock_balance"
            referencedColumns: ["product_id"]
          },
          {
            foreignKeyName: "sales_invoice_items_si_id_fkey"
            columns: ["si_id"]
            isOneToOne: false
            referencedRelation: "sales_invoices"
            referencedColumns: ["id"]
          },
        ]
      }
      sales_invoices: {
        Row: {
          created_at: string
          created_by: string | null
          customer_id: string
          delivery_id: string | null
          discount: number
          due_date: string | null
          id: string
          invoice_date: string
          notes: string | null
          paid_amount: number
          si_no: string
          so_id: string | null
          status: Database["public"]["Enums"]["doc_status"]
          subtotal: number
          tax_total: number
          total: number
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          customer_id: string
          delivery_id?: string | null
          discount?: number
          due_date?: string | null
          id?: string
          invoice_date?: string
          notes?: string | null
          paid_amount?: number
          si_no?: string
          so_id?: string | null
          status?: Database["public"]["Enums"]["doc_status"]
          subtotal?: number
          tax_total?: number
          total?: number
        }
        Update: {
          created_at?: string
          created_by?: string | null
          customer_id?: string
          delivery_id?: string | null
          discount?: number
          due_date?: string | null
          id?: string
          invoice_date?: string
          notes?: string | null
          paid_amount?: number
          si_no?: string
          so_id?: string | null
          status?: Database["public"]["Enums"]["doc_status"]
          subtotal?: number
          tax_total?: number
          total?: number
        }
        Relationships: [
          {
            foreignKeyName: "sales_invoices_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sales_invoices_delivery_id_fkey"
            columns: ["delivery_id"]
            isOneToOne: false
            referencedRelation: "deliveries"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sales_invoices_so_id_fkey"
            columns: ["so_id"]
            isOneToOne: false
            referencedRelation: "sales_orders"
            referencedColumns: ["id"]
          },
        ]
      }
      sales_order_items: {
        Row: {
          id: string
          line_total: number
          product_id: string
          qty: number
          so_id: string
          tax_rate: number
          unit_price: number
        }
        Insert: {
          id?: string
          line_total?: number
          product_id: string
          qty: number
          so_id: string
          tax_rate?: number
          unit_price: number
        }
        Update: {
          id?: string
          line_total?: number
          product_id?: string
          qty?: number
          so_id?: string
          tax_rate?: number
          unit_price?: number
        }
        Relationships: [
          {
            foreignKeyName: "sales_order_items_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sales_order_items_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "v_stock_balance"
            referencedColumns: ["product_id"]
          },
          {
            foreignKeyName: "sales_order_items_so_id_fkey"
            columns: ["so_id"]
            isOneToOne: false
            referencedRelation: "sales_orders"
            referencedColumns: ["id"]
          },
        ]
      }
      sales_orders: {
        Row: {
          created_at: string
          created_by: string | null
          customer_id: string
          delivery_date: string | null
          discount: number
          id: string
          notes: string | null
          order_date: string
          so_no: string
          status: Database["public"]["Enums"]["doc_status"]
          subtotal: number
          tax_total: number
          total: number
          warehouse_id: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          customer_id: string
          delivery_date?: string | null
          discount?: number
          id?: string
          notes?: string | null
          order_date?: string
          so_no?: string
          status?: Database["public"]["Enums"]["doc_status"]
          subtotal?: number
          tax_total?: number
          total?: number
          warehouse_id: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          customer_id?: string
          delivery_date?: string | null
          discount?: number
          id?: string
          notes?: string | null
          order_date?: string
          so_no?: string
          status?: Database["public"]["Enums"]["doc_status"]
          subtotal?: number
          tax_total?: number
          total?: number
          warehouse_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "sales_orders_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sales_orders_warehouse_id_fkey"
            columns: ["warehouse_id"]
            isOneToOne: false
            referencedRelation: "v_stock_balance"
            referencedColumns: ["warehouse_id"]
          },
          {
            foreignKeyName: "sales_orders_warehouse_id_fkey"
            columns: ["warehouse_id"]
            isOneToOne: false
            referencedRelation: "warehouses"
            referencedColumns: ["id"]
          },
        ]
      }
      suppliers: {
        Row: {
          address: string | null
          code: string
          contact_person: string | null
          created_at: string
          email: string | null
          gstin: string | null
          id: string
          is_active: boolean
          name: string
          opening_balance: number
          phone: string | null
        }
        Insert: {
          address?: string | null
          code: string
          contact_person?: string | null
          created_at?: string
          email?: string | null
          gstin?: string | null
          id?: string
          is_active?: boolean
          name: string
          opening_balance?: number
          phone?: string | null
        }
        Update: {
          address?: string | null
          code?: string
          contact_person?: string | null
          created_at?: string
          email?: string | null
          gstin?: string | null
          id?: string
          is_active?: boolean
          name?: string
          opening_balance?: number
          phone?: string | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      warehouses: {
        Row: {
          address: string | null
          code: string
          created_at: string
          id: string
          is_active: boolean
          name: string
        }
        Insert: {
          address?: string | null
          code: string
          created_at?: string
          id?: string
          is_active?: boolean
          name: string
        }
        Update: {
          address?: string | null
          code?: string
          created_at?: string
          id?: string
          is_active?: boolean
          name?: string
        }
        Relationships: []
      }
    }
    Views: {
      v_stock_balance: {
        Row: {
          avg_cost: number | null
          name: string | null
          product_id: string | null
          qty_on_hand: number | null
          sku: string | null
          warehouse_id: string | null
          warehouse_name: string | null
        }
        Relationships: []
      }
    }
    Functions: {
      account_id_by_code: { Args: { _code: string }; Returns: string }
      finalize_purchase_invoice: { Args: { _pi_id: string }; Returns: string }
      finalize_sales_invoice: { Args: { _si_id: string }; Returns: string }
      has_any_role: { Args: { _user_id: string }; Returns: boolean }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_staff: { Args: { _user_id: string }; Returns: boolean }
      next_doc_no: { Args: { _doc_type: string }; Returns: string }
      post_journal: {
        Args: {
          _date: string
          _lines: Json
          _narration: string
          _ref_id: string
          _ref_type: string
        }
        Returns: string
      }
    }
    Enums: {
      account_type: "asset" | "liability" | "equity" | "income" | "expense"
      app_role:
        | "admin"
        | "accountant"
        | "sales_user"
        | "purchase_user"
        | "viewer"
      doc_status: "draft" | "confirmed" | "partial" | "completed" | "cancelled"
      movement_type: "in" | "out" | "adjustment"
      party_type: "customer" | "supplier"
      payment_direction: "received" | "paid"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      account_type: ["asset", "liability", "equity", "income", "expense"],
      app_role: [
        "admin",
        "accountant",
        "sales_user",
        "purchase_user",
        "viewer",
      ],
      doc_status: ["draft", "confirmed", "partial", "completed", "cancelled"],
      movement_type: ["in", "out", "adjustment"],
      party_type: ["customer", "supplier"],
      payment_direction: ["received", "paid"],
    },
  },
} as const
