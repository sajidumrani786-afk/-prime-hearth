import { createFileRoute, Link, Outlet, useNavigate, useRouterState } from "@tanstack/react-router";
import { useEffect } from "react";
import { useAuth } from "@/lib/auth-context";
import { useSettings } from "@/lib/format";
import { Button } from "@/components/ui/button";
import {
  LayoutDashboard, Package, Users, Truck, ShoppingCart, FileText,
  BookOpen, BarChart3, Settings, LogOut, Receipt, Wallet, Boxes,
} from "lucide-react";

export const Route = createFileRoute("/_app")({ component: AppLayout });

const NAV: { section: string; items: { to: string; label: string; icon: any }[] }[] = [
  { section: "Overview", items: [
    { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  ]},
  { section: "Master", items: [
    { to: "/master/products", label: "Products", icon: Package },
    { to: "/master/suppliers", label: "Suppliers", icon: Truck },
    { to: "/master/customers", label: "Customers", icon: Users },
    { to: "/master/warehouses", label: "Warehouses", icon: Boxes },
  ]},
  { section: "Purchase", items: [
    { to: "/purchase/orders", label: "Purchase Orders", icon: ShoppingCart },
    { to: "/purchase/grn", label: "Goods Receipts", icon: Receipt },
    { to: "/purchase/invoices", label: "Purchase Invoices", icon: FileText },
  ]},
  { section: "Sales", items: [
    { to: "/sales/orders", label: "Sales Orders", icon: ShoppingCart },
    { to: "/sales/deliveries", label: "Deliveries", icon: Truck },
    { to: "/sales/invoices", label: "Sales Invoices", icon: FileText },
  ]},
  { section: "Accounting", items: [
    { to: "/accounting/accounts", label: "Chart of Accounts", icon: BookOpen },
    { to: "/accounting/journals", label: "Journal Entries", icon: FileText },
    { to: "/accounting/payments", label: "Payments", icon: Wallet },
  ]},
  { section: "Reports", items: [
    { to: "/reports/ledger", label: "Ledgers", icon: BookOpen },
    { to: "/reports/trial-balance", label: "Trial Balance", icon: BarChart3 },
    { to: "/reports/pl", label: "Profit & Loss", icon: BarChart3 },
    { to: "/reports/balance-sheet", label: "Balance Sheet", icon: BarChart3 },
    { to: "/reports/stock", label: "Stock Report", icon: Package },
  ]},
  { section: "Settings", items: [
    { to: "/settings", label: "Company Settings", icon: Settings },
  ]},
];

function AppLayout() {
  const { user, loading, signOut } = useAuth();
  const nav = useNavigate();
  const path = useRouterState({ select: (s) => s.location.pathname });
  const settings = useSettings();

  useEffect(() => {
    if (!loading && !user) nav({ to: "/login" });
  }, [user, loading, nav]);

  if (loading || !user) {
    return <div className="grid min-h-screen place-items-center text-muted-foreground">Loading…</div>;
  }

  return (
    <div className="flex min-h-screen bg-background">
      <aside className="hidden w-64 shrink-0 flex-col bg-sidebar text-sidebar-foreground md:flex">
        <div className="flex items-center gap-2 px-5 py-4 border-b border-sidebar-border">
          <div className="grid h-8 w-8 place-items-center rounded-md bg-sidebar-primary text-sidebar-primary-foreground font-bold">P</div>
          <div>
            <div className="text-sm font-semibold leading-tight">{settings.data?.company_name ?? "Pharma ERP"}</div>
            <div className="text-xs text-sidebar-foreground/60">Distribution ERP</div>
          </div>
        </div>
        <nav className="flex-1 overflow-y-auto px-2 py-3">
          {NAV.map((s) => (
            <div key={s.section} className="mb-3">
              <div className="px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-sidebar-foreground/50">{s.section}</div>
              {s.items.map((it) => {
                const Icon = it.icon;
                const active = path === it.to;
                return (
                  <Link
                    key={it.to}
                    to={it.to}
                    className={`mx-1 flex items-center gap-2 rounded-md px-3 py-2 text-sm transition-colors ${
                      active
                        ? "bg-sidebar-primary text-sidebar-primary-foreground"
                        : "text-sidebar-foreground/85 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    {it.label}
                  </Link>
                );
              })}
            </div>
          ))}
        </nav>
        <div className="border-t border-sidebar-border p-3">
          <div className="mb-2 truncate px-1 text-xs text-sidebar-foreground/70">{user.email}</div>
          <Button
            variant="secondary"
            size="sm"
            className="w-full"
            onClick={async () => { await signOut(); nav({ to: "/login" }); }}
          >
            <LogOut className="mr-1 h-4 w-4" /> Sign out
          </Button>
        </div>
      </aside>
      <main className="flex-1 overflow-x-hidden">
        <div className="border-b bg-card md:hidden flex items-center justify-between px-4 py-3">
          <span className="font-semibold">Pharma ERP</span>
          <Button size="sm" variant="ghost" onClick={() => signOut()}>Sign out</Button>
        </div>
        <div className="p-6">
          <Outlet />
        </div>
      </main>
    </div>
  );
}