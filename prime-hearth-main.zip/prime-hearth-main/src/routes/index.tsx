import { createFileRoute } from "@tanstack/react-router";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth-context";
import { useEffect } from "react";
import { useNavigate } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  component: Index,
});

function Index() {
  const { user, loading } = useAuth();
  const nav = useNavigate();
  useEffect(() => {
    if (!loading && user) nav({ to: "/dashboard" });
  }, [user, loading, nav]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary to-accent/30">
      <header className="container mx-auto flex items-center justify-between px-6 py-6">
        <div className="flex items-center gap-2">
          <div className="grid h-9 w-9 place-items-center rounded-lg bg-primary text-primary-foreground font-bold">P</div>
          <span className="text-lg font-semibold">Pharma ERP</span>
        </div>
        <div className="flex gap-2">
          <Button asChild variant="ghost"><Link to="/login">Login</Link></Button>
          <Button asChild><Link to="/signup">Get Started</Link></Button>
        </div>
      </header>
      <main className="container mx-auto px-6 py-20 text-center">
        <h1 className="mx-auto max-w-3xl text-5xl font-bold tracking-tight">
          Distribution ERP for modern pharma businesses
        </h1>
        <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground">
          Vendors, Suppliers, Purchase, Sales, Inventory, Double-entry Accounting,
          Ledgers and Reports — all in one place.
        </p>
        <div className="mt-10 flex justify-center gap-3">
          <Button asChild size="lg"><Link to="/signup">Create your account</Link></Button>
          <Button asChild size="lg" variant="outline"><Link to="/login">Sign in</Link></Button>
        </div>
        <div className="mx-auto mt-20 grid max-w-5xl grid-cols-1 gap-4 md:grid-cols-3">
          {[
            ["Purchase", "PO → GRN → Invoice → Payment with auto journal entries."],
            ["Sales", "SO → Delivery → Invoice → Payment with COGS posting."],
            ["Accounting", "Ledgers, Trial Balance, P&L, Balance Sheet — all auto."],
          ].map(([t, d]) => (
            <div key={t} className="rounded-xl border bg-card p-6 text-left shadow-sm">
              <div className="font-semibold">{t}</div>
              <p className="mt-2 text-sm text-muted-foreground">{d}</p>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
