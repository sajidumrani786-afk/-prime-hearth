import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { PageHeader } from "@/components/erp/PageHeader";
import { DataTable } from "@/components/erp/DataTable";
import { CrudDialog } from "@/components/erp/CrudDialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useList } from "@/lib/crud";
import { fmtMoney, fmtDate, useSettings } from "@/lib/format";
import { LineItemsEditor, emptyLine, totals, type LineItem } from "@/components/erp/LineItemsEditor";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Plus, Trash2, Printer } from "lucide-react";
import { InvoicePrint } from "@/components/erp/print/InvoicePrint";

export const Route = createFileRoute("/_app/sales/invoices")({ component: Page });

function Page() {
  const list = useList<any>("sales_invoices", { order: "created_at" });
  const customers = useList<any>("customers", { order: "name", ascending: true });
  const products = useList<any>("products", { order: "name", ascending: true });
  const settings = useSettings();
  const sym = settings.data?.currency_symbol ?? "₹";
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [printId, setPrintId] = useState<string | null>(null);
  const [hdr, setHdr] = useState({ customer_id: "", invoice_date: new Date().toISOString().slice(0, 10), due_date: "", discount: 0, notes: "" });
  const [items, setItems] = useState<LineItem[]>([emptyLine()]);
  const t = totals(items, hdr.discount);

  async function save() {
    if (!hdr.customer_id) { toast.error("Customer required"); return false; }
    const valid = items.filter((l) => l.product_id && l.qty > 0);
    if (!valid.length) { toast.error("Add lines"); return false; }
    const { data: si, error } = await supabase.from("sales_invoices").insert({
      customer_id: hdr.customer_id, invoice_date: hdr.invoice_date,
      due_date: hdr.due_date || null, discount: hdr.discount, notes: hdr.notes,
    }).select().single();
    if (error) { toast.error(error.message); return false; }
    const rows = valid.map((l) => ({ si_id: si.id, product_id: l.product_id, qty: l.qty, unit_price: l.unit_price, tax_rate: l.tax_rate, line_total: l.qty * l.unit_price * (1 + l.tax_rate / 100) }));
    const { error: e2 } = await supabase.from("sales_invoice_items").insert(rows);
    if (e2) { toast.error(e2.message); return false; }
    const { error: e3 } = await supabase.rpc("finalize_sales_invoice", { _si_id: si.id });
    if (e3) toast.error(`Posted invoice but journal failed: ${e3.message}`);
    else toast.success("Sales Invoice posted with journal entry");
    qc.invalidateQueries({ queryKey: ["sales_invoices", "list"] });
    setHdr({ customer_id: "", invoice_date: new Date().toISOString().slice(0, 10), due_date: "", discount: 0, notes: "" });
    setItems([emptyLine()]);
  }
  async function del(id: string) {
    const jes = (await supabase.from("journal_entries").select("id").or(`reference_type.eq.sales_invoice,reference_type.eq.sales_invoice_cogs`).eq("reference_id", id)).data ?? [];
    if (jes.length) {
      await supabase.from("journal_lines").delete().in("journal_id", jes.map((j: any) => j.id));
      await supabase.from("journal_entries").delete().in("id", jes.map((j: any) => j.id));
    }
    await supabase.from("sales_invoice_items").delete().eq("si_id", id);
    const { error } = await supabase.from("sales_invoices").delete().eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["sales_invoices", "list"] });
  }
  const cName = (id: string) => customers.data?.find((c) => c.id === id)?.name ?? "—";

  return (
    <>
      <PageHeader title="Sales Invoices" actions={<Button onClick={() => setOpen(true)}><Plus className="mr-1 h-4 w-4" /> New SI</Button>} />
      <DataTable data={list.data} columns={[
        { header: "SI No", cell: (r: any) => <span className="font-mono text-xs">{r.si_no}</span> },
        { header: "Date", cell: (r: any) => fmtDate(r.invoice_date) },
        { header: "Customer", cell: (r: any) => cName(r.customer_id) },
        { header: "Total", cell: (r: any) => fmtMoney(r.total, sym), className: "text-right" },
        { header: "Paid", cell: (r: any) => fmtMoney(r.paid_amount, sym), className: "text-right" },
        { header: "Due", cell: (r: any) => fmtMoney(Number(r.total) - Number(r.paid_amount), sym), className: "text-right" },
        { header: "", cell: (r: any) => (
          <div className="flex justify-end gap-1">
            <Button size="icon" variant="ghost" onClick={() => setPrintId(r.id)}><Printer className="h-4 w-4" /></Button>
            <Button size="icon" variant="ghost" onClick={() => del(r.id)}><Trash2 className="h-4 w-4" /></Button>
          </div>
        ) },
      ]} />
      <InvoicePrint open={!!printId} onOpenChange={(v) => !v && setPrintId(null)} invoiceId={printId} mode="sales" />
      <CrudDialog title="New Sales Invoice" open={open} onOpenChange={setOpen} onSubmit={save}>
        <div className="grid gap-4 sm:grid-cols-2">
          <div><Label>Customer *</Label>
            <Select value={hdr.customer_id} onValueChange={(v) => setHdr({ ...hdr, customer_id: v })}>
              <SelectTrigger><SelectValue placeholder="Select customer" /></SelectTrigger>
              <SelectContent>{customers.data?.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div><Label>Invoice Date</Label><Input type="date" value={hdr.invoice_date} onChange={(e) => setHdr({ ...hdr, invoice_date: e.target.value })} /></div>
          <div><Label>Due Date</Label><Input type="date" value={hdr.due_date} onChange={(e) => setHdr({ ...hdr, due_date: e.target.value })} /></div>
          <div><Label>Discount</Label><Input type="number" value={hdr.discount} onChange={(e) => setHdr({ ...hdr, discount: +e.target.value })} /></div>
          <div className="sm:col-span-2"><Label>Notes</Label><Input value={hdr.notes} onChange={(e) => setHdr({ ...hdr, notes: e.target.value })} /></div>
        </div>
        <LineItemsEditor items={items} setItems={setItems} products={products.data ?? []} mode="sales" sym={sym} />
        <div className="flex justify-end text-sm">
          <div className="space-y-1 text-right">
            <div>Subtotal: <span className="font-medium">{fmtMoney(t.subtotal, sym)}</span></div>
            <div>Tax: <span className="font-medium">{fmtMoney(t.tax, sym)}</span></div>
            <div>Discount: <span className="font-medium">{fmtMoney(hdr.discount, sym)}</span></div>
            <div className="text-base">Total: <span className="font-bold">{fmtMoney(t.total, sym)}</span></div>
          </div>
        </div>
      </CrudDialog>
    </>
  );
}
