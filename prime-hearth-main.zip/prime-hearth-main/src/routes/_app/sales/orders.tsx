import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { PageHeader } from "@/components/erp/PageHeader";
import { DataTable } from "@/components/erp/DataTable";
import { CrudDialog } from "@/components/erp/CrudDialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useList } from "@/lib/crud";
import { fmtMoney, fmtDate, useSettings } from "@/lib/format";
import { LineItemsEditor, emptyLine, totals, type LineItem } from "@/components/erp/LineItemsEditor";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Plus, Trash2 } from "lucide-react";

export const Route = createFileRoute("/_app/sales/orders")({ component: Page });

function Page() {
  const list = useList<any>("sales_orders", { order: "created_at" });
  const customers = useList<any>("customers", { order: "name", ascending: true });
  const warehouses = useList<any>("warehouses", { order: "name", ascending: true });
  const products = useList<any>("products", { order: "name", ascending: true });
  const settings = useSettings();
  const sym = settings.data?.currency_symbol ?? "₹";
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [hdr, setHdr] = useState({ customer_id: "", warehouse_id: "", order_date: new Date().toISOString().slice(0, 10), delivery_date: "", notes: "" });
  const [items, setItems] = useState<LineItem[]>([emptyLine()]);
  const t = totals(items);

  async function save() {
    if (!hdr.customer_id || !hdr.warehouse_id) { toast.error("Customer & warehouse required"); return false; }
    const valid = items.filter((l) => l.product_id && l.qty > 0);
    if (!valid.length) { toast.error("Add lines"); return false; }
    const { data: so, error } = await supabase.from("sales_orders").insert({
      customer_id: hdr.customer_id, warehouse_id: hdr.warehouse_id,
      order_date: hdr.order_date, delivery_date: hdr.delivery_date || null, notes: hdr.notes,
      subtotal: t.subtotal, tax_total: t.tax, total: t.total, status: "confirmed",
    }).select().single();
    if (error) { toast.error(error.message); return false; }
    const rows = valid.map((l) => ({ so_id: so.id, product_id: l.product_id, qty: l.qty, unit_price: l.unit_price, tax_rate: l.tax_rate, line_total: l.qty * l.unit_price * (1 + l.tax_rate / 100) }));
    const { error: e2 } = await supabase.from("sales_order_items").insert(rows);
    if (e2) { toast.error(e2.message); return false; }
    toast.success("Sales Order created");
    qc.invalidateQueries({ queryKey: ["sales_orders", "list"] });
    setHdr({ customer_id: "", warehouse_id: "", order_date: new Date().toISOString().slice(0, 10), delivery_date: "", notes: "" });
    setItems([emptyLine()]);
  }
  async function del(id: string) {
    await supabase.from("sales_order_items").delete().eq("so_id", id);
    const { error } = await supabase.from("sales_orders").delete().eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["sales_orders", "list"] });
  }
  const cName = (id: string) => customers.data?.find((c) => c.id === id)?.name ?? "—";

  return (
    <>
      <PageHeader title="Sales Orders" actions={<Button onClick={() => setOpen(true)}><Plus className="mr-1 h-4 w-4" /> New SO</Button>} />
      <DataTable data={list.data} columns={[
        { header: "SO No", cell: (r: any) => <span className="font-mono text-xs">{r.so_no}</span> },
        { header: "Date", cell: (r: any) => fmtDate(r.order_date) },
        { header: "Customer", cell: (r: any) => cName(r.customer_id) },
        { header: "Status", cell: (r: any) => <span className="capitalize">{r.status}</span> },
        { header: "Total", cell: (r: any) => fmtMoney(r.total, sym), className: "text-right" },
        { header: "", cell: (r: any) => <Button size="icon" variant="ghost" onClick={() => del(r.id)}><Trash2 className="h-4 w-4" /></Button> },
      ]} />
      <CrudDialog title="New Sales Order" open={open} onOpenChange={setOpen} onSubmit={save}>
        <div className="grid gap-4 sm:grid-cols-2">
          <div><Label>Customer *</Label>
            <Select value={hdr.customer_id} onValueChange={(v) => setHdr({ ...hdr, customer_id: v })}>
              <SelectTrigger><SelectValue placeholder="Select customer" /></SelectTrigger>
              <SelectContent>{customers.data?.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div><Label>Warehouse *</Label>
            <Select value={hdr.warehouse_id} onValueChange={(v) => setHdr({ ...hdr, warehouse_id: v })}>
              <SelectTrigger><SelectValue placeholder="Select warehouse" /></SelectTrigger>
              <SelectContent>{warehouses.data?.map((w) => <SelectItem key={w.id} value={w.id}>{w.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div><Label>Order Date</Label><Input type="date" value={hdr.order_date} onChange={(e) => setHdr({ ...hdr, order_date: e.target.value })} /></div>
          <div><Label>Delivery Date</Label><Input type="date" value={hdr.delivery_date} onChange={(e) => setHdr({ ...hdr, delivery_date: e.target.value })} /></div>
          <div className="sm:col-span-2"><Label>Notes</Label><Input value={hdr.notes} onChange={(e) => setHdr({ ...hdr, notes: e.target.value })} /></div>
        </div>
        <LineItemsEditor items={items} setItems={setItems} products={products.data ?? []} mode="sales" sym={sym} />
        <div className="flex justify-end text-sm">
          <div className="space-y-1 text-right">
            <div>Subtotal: <span className="font-medium">{fmtMoney(t.subtotal, sym)}</span></div>
            <div>Tax: <span className="font-medium">{fmtMoney(t.tax, sym)}</span></div>
            <div className="text-base">Total: <span className="font-bold">{fmtMoney(t.total, sym)}</span></div>
          </div>
        </div>
      </CrudDialog>
    </>
  );
}
