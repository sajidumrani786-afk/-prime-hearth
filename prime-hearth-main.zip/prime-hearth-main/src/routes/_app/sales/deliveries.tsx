import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { PageHeader } from "@/components/erp/PageHeader";
import { DataTable } from "@/components/erp/DataTable";
import { CrudDialog } from "@/components/erp/CrudDialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useList } from "@/lib/crud";
import { fmtDate } from "@/lib/format";
import { LineItemsEditor, emptyLine, type LineItem } from "@/components/erp/LineItemsEditor";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Plus, Trash2, Printer } from "lucide-react";
import { DeliveryPrint } from "@/components/erp/print/DeliveryPrint";

export const Route = createFileRoute("/_app/sales/deliveries")({ component: Page });

function Page() {
  const list = useList<any>("deliveries", { order: "created_at" });
  const customers = useList<any>("customers", { order: "name", ascending: true });
  const warehouses = useList<any>("warehouses", { order: "name", ascending: true });
  const products = useList<any>("products", { order: "name", ascending: true });
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [printId, setPrintId] = useState<string | null>(null);
  const [hdr, setHdr] = useState({ customer_id: "", warehouse_id: "", delivery_date: new Date().toISOString().slice(0, 10), notes: "" });
  const [items, setItems] = useState<LineItem[]>([emptyLine()]);

  async function save() {
    if (!hdr.customer_id || !hdr.warehouse_id) { toast.error("Customer & warehouse required"); return false; }
    const valid = items.filter((l) => l.product_id && l.qty > 0);
    if (!valid.length) { toast.error("Add lines"); return false; }
    const { data: d, error } = await supabase.from("deliveries").insert({
      customer_id: hdr.customer_id, warehouse_id: hdr.warehouse_id, delivery_date: hdr.delivery_date, notes: hdr.notes,
    }).select().single();
    if (error) { toast.error(error.message); return false; }
    const rows = valid.map((l) => ({ delivery_id: d.id, product_id: l.product_id, qty: l.qty, unit_cost: 0 }));
    const { error: e2 } = await supabase.from("delivery_items").insert(rows);
    if (e2) { toast.error(e2.message); return false; }
    toast.success("Delivery posted (stock reduced)");
    qc.invalidateQueries({ queryKey: ["deliveries", "list"] });
    setHdr({ customer_id: "", warehouse_id: "", delivery_date: new Date().toISOString().slice(0, 10), notes: "" });
    setItems([emptyLine()]);
  }
  async function del(id: string) {
    await supabase.from("inventory_movements").delete().eq("reference_type", "delivery").eq("reference_id", id);
    await supabase.from("delivery_items").delete().eq("delivery_id", id);
    const { error } = await supabase.from("deliveries").delete().eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["deliveries", "list"] });
  }
  const cName = (id: string) => customers.data?.find((c) => c.id === id)?.name ?? "—";

  return (
    <>
      <PageHeader title="Deliveries" actions={<Button onClick={() => setOpen(true)}><Plus className="mr-1 h-4 w-4" /> New Delivery</Button>} />
      <DataTable data={list.data} columns={[
        { header: "DLV No", cell: (r: any) => <span className="font-mono text-xs">{r.dlv_no}</span> },
        { header: "Date", cell: (r: any) => fmtDate(r.delivery_date) },
        { header: "Customer", cell: (r: any) => cName(r.customer_id) },
        { header: "Status", cell: (r: any) => <span className="capitalize">{r.status}</span> },
        { header: "", cell: (r: any) => (
          <div className="flex justify-end gap-1">
            <Button size="icon" variant="ghost" onClick={() => setPrintId(r.id)}><Printer className="h-4 w-4" /></Button>
            <Button size="icon" variant="ghost" onClick={() => del(r.id)}><Trash2 className="h-4 w-4" /></Button>
          </div>
        ) },
      ]} />
      <DeliveryPrint open={!!printId} onOpenChange={(v) => !v && setPrintId(null)} deliveryId={printId} />
      <CrudDialog title="New Delivery" open={open} onOpenChange={setOpen} onSubmit={save}>
        <div className="grid gap-4 sm:grid-cols-2">
          <div><Label>Customer *</Label>
            <Select value={hdr.customer_id} onValueChange={(v) => setHdr({ ...hdr, customer_id: v })}>
              <SelectTrigger><SelectValue placeholder="Select customer" /></SelectTrigger>
              <SelectContent>{customers.data?.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div><Label>Warehouse *</Label>
            <Select value={hdr.warehouse_id} onValueChange={(v) => setHdr({ ...hdr, warehouse_id: v })}>
              <SelectTrigger><SelectValue placeholder="Select warehouse" /></SelectTrigger>
              <SelectContent>{warehouses.data?.map((w) => <SelectItem key={w.id} value={w.id}>{w.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div><Label>Delivery Date</Label><Input type="date" value={hdr.delivery_date} onChange={(e) => setHdr({ ...hdr, delivery_date: e.target.value })} /></div>
          <div className="sm:col-span-2"><Label>Notes</Label><Input value={hdr.notes} onChange={(e) => setHdr({ ...hdr, notes: e.target.value })} /></div>
        </div>
        <LineItemsEditor items={items} setItems={setItems} products={products.data ?? []} mode="sales" />
      </CrudDialog>
    </>
  );
}
