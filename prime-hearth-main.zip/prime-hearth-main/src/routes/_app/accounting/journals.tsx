import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { PageHeader } from "@/components/erp/PageHeader";
import { supabase } from "@/integrations/supabase/client";
import { fmtMoney, fmtDate, useSettings } from "@/lib/format";
import { Card } from "@/components/ui/card";

export const Route = createFileRoute("/_app/accounting/journals")({ component: Page });

function Page() {
  const settings = useSettings();
  const sym = settings.data?.currency_symbol ?? "₹";
  const q = useQuery({
    queryKey: ["journal-entries-full"],
    queryFn: async () => {
      const { data: jes } = await supabase.from("journal_entries").select("*").order("entry_date", { ascending: false }).limit(200);
      const ids = (jes ?? []).map((j: any) => j.id);
      const { data: lines } = ids.length ? await supabase.from("journal_lines").select("*").in("journal_id", ids) : { data: [] as any[] };
      const { data: accts } = await supabase.from("accounts").select("id, code, name");
      const accMap = new Map((accts ?? []).map((a: any) => [a.id, a]));
      return (jes ?? []).map((j: any) => ({
        ...j,
        lines: (lines ?? []).filter((l: any) => l.journal_id === j.id).map((l: any) => ({ ...l, account: accMap.get(l.account_id) })),
      }));
    },
  });

  return (
    <>
      <PageHeader title="Journal Entries" description="Auto-generated double-entry postings" />
      <div className="space-y-4">
        {q.data?.length === 0 && <p className="text-sm text-muted-foreground">No journal entries yet.</p>}
        {q.data?.map((j: any) => {
          const dr = j.lines.reduce((s: number, l: any) => s + Number(l.debit), 0);
          const cr = j.lines.reduce((s: number, l: any) => s + Number(l.credit), 0);
          return (
            <Card key={j.id} className="p-4">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b pb-2">
                <div>
                  <div className="font-mono text-xs">{j.entry_no}</div>
                  <div className="text-sm font-medium">{j.narration}</div>
                </div>
                <div className="text-xs text-muted-foreground">{fmtDate(j.entry_date)}</div>
              </div>
              <table className="w-full text-sm mt-2">
                <thead><tr className="text-xs text-muted-foreground"><th className="text-left">Account</th><th className="text-right">Debit</th><th className="text-right">Credit</th></tr></thead>
                <tbody>
                  {j.lines.map((l: any) => (
                    <tr key={l.id} className="border-t">
                      <td className="py-1"><span className="font-mono text-xs">{l.account?.code}</span> {l.account?.name} {l.description && <span className="text-muted-foreground">— {l.description}</span>}</td>
                      <td className="text-right">{Number(l.debit) > 0 ? fmtMoney(l.debit, sym) : ""}</td>
                      <td className="text-right">{Number(l.credit) > 0 ? fmtMoney(l.credit, sym) : ""}</td>
                    </tr>
                  ))}
                  <tr className="border-t font-medium">
                    <td>Totals</td>
                    <td className="text-right">{fmtMoney(dr, sym)}</td>
                    <td className="text-right">{fmtMoney(cr, sym)}</td>
                  </tr>
                </tbody>
              </table>
            </Card>
          );
        })}
      </div>
    </>
  );
}
