import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader } from "@/components/erp/PageHeader";
import { DataTable } from "@/components/erp/DataTable";
import { CrudDialog } from "@/components/erp/CrudDialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useList, useUpsert, useDelete } from "@/lib/crud";
import { Plus, Trash2 } from "lucide-react";

export const Route = createFileRoute("/_app/accounting/accounts")({ component: Page });

const TYPES = ["asset", "liability", "equity", "income", "expense"];

function Page() {
  const list = useList<any>("accounts", { order: "code", ascending: true });
  const upsert = useUpsert("accounts");
  const del = useDelete("accounts");
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ code: "", name: "", type: "asset" });
  return (
    <>
      <PageHeader title="Chart of Accounts" actions={<Button onClick={() => setOpen(true)}><Plus className="mr-1 h-4 w-4" /> New Account</Button>} />
      <DataTable data={list.data} columns={[
        { header: "Code", cell: (r: any) => <span className="font-mono">{r.code}</span> },
        { header: "Name", cell: (r: any) => r.name },
        { header: "Type", cell: (r: any) => <span className="capitalize">{r.type}</span> },
        { header: "System", cell: (r: any) => r.is_system ? "Yes" : "—" },
        { header: "", cell: (r: any) => !r.is_system && <Button size="icon" variant="ghost" onClick={() => del.mutate(r.id)}><Trash2 className="h-4 w-4" /></Button> },
      ]} />
      <CrudDialog title="New Account" open={open} onOpenChange={setOpen}
        onSubmit={async () => { if (!f.code || !f.name) return false; await upsert.mutateAsync(f); setF({ code: "", name: "", type: "asset" }); }}>
        <div className="grid gap-4 sm:grid-cols-2">
          <div><Label>Code *</Label><Input value={f.code} onChange={(e) => setF({ ...f, code: e.target.value })} /></div>
          <div><Label>Name *</Label><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></div>
          <div className="sm:col-span-2"><Label>Type</Label>
            <Select value={f.type} onValueChange={(v) => setF({ ...f, type: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{TYPES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
            </Select>
          </div>
        </div>
      </CrudDialog>
    </>
  );
}
