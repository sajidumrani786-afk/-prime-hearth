import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { PageHeader } from "@/components/erp/PageHeader";
import { DataTable } from "@/components/erp/DataTable";
import { CrudDialog } from "@/components/erp/CrudDialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useList } from "@/lib/crud";
import { fmtMoney, fmtDate, useSettings } from "@/lib/format";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Plus, Trash2 } from "lucide-react";

export const Route = createFileRoute("/_app/accounting/payments")({ component: Page });

function Page() {
  const list = useList<any>("payments", { order: "created_at" });
  const customers = useList<any>("customers", { order: "name", ascending: true });
  const suppliers = useList<any>("suppliers", { order: "name", ascending: true });
  const sInvs = useList<any>("sales_invoices", { order: "created_at" });
  const pInvs = useList<any>("purchase_invoices", { order: "created_at" });
  const settings = useSettings();
  const sym = settings.data?.currency_symbol ?? "₹";
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ direction: "received", party_type: "customer", party_id: "", invoice_id: "", amount: 0, method: "cash", payment_date: new Date().toISOString().slice(0, 10), notes: "" });

  async function save() {
    if (!f.party_id || !f.amount) { toast.error("Party & amount required"); return false; }
    const payload: any = { ...f, invoice_id: f.invoice_id || null };
    const { error } = await supabase.from("payments").insert(payload);
    if (error) { toast.error(error.message); return false; }
    toast.success("Payment posted with journal");
    qc.invalidateQueries({ queryKey: ["payments", "list"] });
    qc.invalidateQueries({ queryKey: ["sales_invoices", "list"] });
    qc.invalidateQueries({ queryKey: ["purchase_invoices", "list"] });
    setF({ direction: "received", party_type: "customer", party_id: "", invoice_id: "", amount: 0, method: "cash", payment_date: new Date().toISOString().slice(0, 10), notes: "" });
  }
  async function del(id: string) {
    const jes = (await supabase.from("journal_entries").select("id").eq("reference_type", "payment").eq("reference_id", id)).data ?? [];
    if (jes.length) {
      await supabase.from("journal_lines").delete().in("journal_id", jes.map((j: any) => j.id));
      await supabase.from("journal_entries").delete().in("id", jes.map((j: any) => j.id));
    }
    const { error } = await supabase.from("payments").delete().eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["payments", "list"] });
  }

  const partyName = (r: any) => (r.party_type === "customer" ? customers.data?.find((c) => c.id === r.party_id)?.name : suppliers.data?.find((s) => s.id === r.party_id)?.name) ?? "—";
  const parties = f.party_type === "customer" ? customers.data : suppliers.data;
  const invoices = f.party_type === "customer"
    ? sInvs.data?.filter((s) => s.customer_id === f.party_id).map((s) => ({ id: s.id, label: `${s.si_no} — Due ${(Number(s.total) - Number(s.paid_amount)).toFixed(2)}` })) ?? []
    : pInvs.data?.filter((p) => p.supplier_id === f.party_id).map((p) => ({ id: p.id, label: `${p.pi_no} — Due ${(Number(p.total) - Number(p.paid_amount)).toFixed(2)}` })) ?? [];

  return (
    <>
      <PageHeader title="Payments" description="Customer receipts & supplier payments" actions={<Button onClick={() => setOpen(true)}><Plus className="mr-1 h-4 w-4" /> New Payment</Button>} />
      <DataTable data={list.data} columns={[
        { header: "No", cell: (r: any) => <span className="font-mono text-xs">{r.pay_no}</span> },
        { header: "Date", cell: (r: any) => fmtDate(r.payment_date) },
        { header: "Direction", cell: (r: any) => <span className="capitalize">{r.direction}</span> },
        { header: "Party", cell: (r: any) => `${r.party_type}: ${partyName(r)}` },
        { header: "Method", cell: (r: any) => r.method },
        { header: "Amount", cell: (r: any) => fmtMoney(r.amount, sym), className: "text-right" },
        { header: "", cell: (r: any) => <Button size="icon" variant="ghost" onClick={() => del(r.id)}><Trash2 className="h-4 w-4" /></Button> },
      ]} />
      <CrudDialog title="New Payment" open={open} onOpenChange={setOpen} onSubmit={save}>
        <div className="grid gap-4 sm:grid-cols-2">
          <div><Label>Direction</Label>
            <Select value={f.direction} onValueChange={(v) => setF({ ...f, direction: v, party_type: v === "received" ? "customer" : "supplier", party_id: "", invoice_id: "" })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="received">Received (from Customer)</SelectItem>
                <SelectItem value="paid">Paid (to Supplier)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div><Label>Method</Label>
            <Select value={f.method} onValueChange={(v) => setF({ ...f, method: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="cash">Cash</SelectItem>
                <SelectItem value="bank">Bank</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div><Label>{f.party_type === "customer" ? "Customer" : "Supplier"} *</Label>
            <Select value={f.party_id} onValueChange={(v) => setF({ ...f, party_id: v, invoice_id: "" })}>
              <SelectTrigger><SelectValue placeholder="Select party" /></SelectTrigger>
              <SelectContent>{parties?.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div><Label>Invoice (optional)</Label>
            <Select value={f.invoice_id || "none"} onValueChange={(v) => setF({ ...f, invoice_id: v === "none" ? "" : v })}>
              <SelectTrigger><SelectValue placeholder="On account" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="none">— On account —</SelectItem>
                {invoices.map((i) => <SelectItem key={i.id} value={i.id}>{i.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div><Label>Date</Label><Input type="date" value={f.payment_date} onChange={(e) => setF({ ...f, payment_date: e.target.value })} /></div>
          <div><Label>Amount *</Label><Input type="number" value={f.amount} onChange={(e) => setF({ ...f, amount: +e.target.value })} /></div>
          <div className="sm:col-span-2"><Label>Notes</Label><Input value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} /></div>
        </div>
      </CrudDialog>
    </>
  );
}
