import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { PageHeader } from "@/components/erp/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useSettings } from "@/lib/format";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";

export const Route = createFileRoute("/_app/settings")({ component: SettingsPage });

const CURRENCIES: { code: string; symbol: string; name: string }[] = [
  { code: "INR", symbol: "₹", name: "Indian Rupee" },
  { code: "USD", symbol: "$", name: "US Dollar" },
  { code: "EUR", symbol: "€", name: "Euro" },
  { code: "GBP", symbol: "£", name: "British Pound" },
  { code: "AED", symbol: "د.إ", name: "UAE Dirham" },
  { code: "SAR", symbol: "﷼", name: "Saudi Riyal" },
  { code: "PKR", symbol: "₨", name: "Pakistani Rupee" },
  { code: "BDT", symbol: "৳", name: "Bangladeshi Taka" },
  { code: "LKR", symbol: "Rs", name: "Sri Lankan Rupee" },
  { code: "NPR", symbol: "₨", name: "Nepalese Rupee" },
  { code: "CNY", symbol: "¥", name: "Chinese Yuan" },
  { code: "JPY", symbol: "¥", name: "Japanese Yen" },
  { code: "AUD", symbol: "A$", name: "Australian Dollar" },
  { code: "CAD", symbol: "C$", name: "Canadian Dollar" },
  { code: "SGD", symbol: "S$", name: "Singapore Dollar" },
  { code: "MYR", symbol: "RM", name: "Malaysian Ringgit" },
  { code: "ZAR", symbol: "R", name: "South African Rand" },
  { code: "NGN", symbol: "₦", name: "Nigerian Naira" },
  { code: "KES", symbol: "KSh", name: "Kenyan Shilling" },
  { code: "BRL", symbol: "R$", name: "Brazilian Real" },
];

function SettingsPage() {
  const s = useSettings();
  const qc = useQueryClient();
  const [f, setF] = useState({ company_name: "", currency_code: "INR", currency_symbol: "₹", tax_mode: "gst", default_tax_rate: 12, fiscal_year_start_month: 4 });
  useEffect(() => { if (s.data) setF(s.data as any); }, [s.data]);

  async function save() {
    const { error } = await supabase.from("company_settings").update(f).eq("id", 1);
    if (error) return toast.error(error.message);
    toast.success("Settings saved");
    qc.invalidateQueries({ queryKey: ["company_settings"] });
  }

  return (
    <>
      <PageHeader title="Company Settings" description="Configure company, currency and taxes" />
      <Card><CardContent className="grid gap-4 p-6 sm:grid-cols-2">
        <div><Label>Company Name</Label><Input value={f.company_name} onChange={(e) => setF({ ...f, company_name: e.target.value })} /></div>
        <div>
          <Label>Currency</Label>
          <Select
            value={f.currency_code}
            onValueChange={(code) => {
              const c = CURRENCIES.find((x) => x.code === code);
              setF({ ...f, currency_code: code, currency_symbol: c?.symbol ?? f.currency_symbol });
            }}
          >
            <SelectTrigger><SelectValue placeholder="Select currency" /></SelectTrigger>
            <SelectContent>
              {CURRENCIES.map((c) => (
                <SelectItem key={c.code} value={c.code}>
                  {c.symbol} — {c.code} ({c.name})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div><Label>Currency Symbol</Label><Input value={f.currency_symbol} onChange={(e) => setF({ ...f, currency_symbol: e.target.value })} /></div>
        <div>
          <Label>Tax Mode</Label>
          <Select value={f.tax_mode} onValueChange={(v) => setF({ ...f, tax_mode: v })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="gst">GST (India)</SelectItem>
              <SelectItem value="vat">VAT</SelectItem>
              <SelectItem value="sales_tax">Sales Tax</SelectItem>
              <SelectItem value="none">No Tax</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div><Label>Default Tax Rate %</Label><Input type="number" value={f.default_tax_rate} onChange={(e) => setF({ ...f, default_tax_rate: +e.target.value })} /></div>
        <div><Label>Fiscal Year Start Month</Label><Input type="number" min={1} max={12} value={f.fiscal_year_start_month} onChange={(e) => setF({ ...f, fiscal_year_start_month: +e.target.value })} /></div>
        <div className="sm:col-span-2"><Button onClick={save}>Save Settings</Button></div>
      </CardContent></Card>
    </>
  );
}
