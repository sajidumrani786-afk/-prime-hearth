import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { PageHeader } from "@/components/erp/PageHeader";
import { DataTable } from "@/components/erp/DataTable";
import { CrudDialog } from "@/components/erp/CrudDialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useList } from "@/lib/crud";
import { fmtDate } from "@/lib/format";
import { LineItemsEditor, emptyLine, type LineItem } from "@/components/erp/LineItemsEditor";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Plus, Trash2 } from "lucide-react";

export const Route = createFileRoute("/_app/purchase/grn")({ component: Page });

function Page() {
  const list = useList<any>("goods_receipts", { order: "created_at" });
  const suppliers = useList<any>("suppliers", { order: "name", ascending: true });
  const warehouses = useList<any>("warehouses", { order: "name", ascending: true });
  const products = useList<any>("products", { order: "name", ascending: true });
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [hdr, setHdr] = useState({ supplier_id: "", warehouse_id: "", receipt_date: new Date().toISOString().slice(0, 10), notes: "" });
  const [items, setItems] = useState<LineItem[]>([emptyLine()]);

  async function save() {
    if (!hdr.supplier_id || !hdr.warehouse_id) { toast.error("Supplier & warehouse required"); return false; }
    const valid = items.filter((l) => l.product_id && l.qty > 0);
    if (!valid.length) { toast.error("Add lines"); return false; }
    const { data: g, error } = await supabase.from("goods_receipts").insert({
      supplier_id: hdr.supplier_id, warehouse_id: hdr.warehouse_id, receipt_date: hdr.receipt_date, notes: hdr.notes,
    }).select().single();
    if (error) { toast.error(error.message); return false; }
    const rows = valid.map((l) => ({ grn_id: g.id, product_id: l.product_id, qty: l.qty, unit_cost: l.unit_price }));
    const { error: e2 } = await supabase.from("goods_receipt_items").insert(rows);
    if (e2) { toast.error(e2.message); return false; }
    toast.success("Goods Receipt posted (stock updated)");
    qc.invalidateQueries({ queryKey: ["goods_receipts", "list"] });
    setHdr({ supplier_id: "", warehouse_id: "", receipt_date: new Date().toISOString().slice(0, 10), notes: "" });
    setItems([emptyLine()]);
  }

  async function del(id: string) {
    await supabase.from("inventory_movements").delete().eq("reference_type", "grn").eq("reference_id", id);
    await supabase.from("goods_receipt_items").delete().eq("grn_id", id);
    const { error } = await supabase.from("goods_receipts").delete().eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["goods_receipts", "list"] });
  }
  const supName = (id: string) => suppliers.data?.find((s) => s.id === id)?.name ?? "—";

  return (
    <>
      <PageHeader title="Goods Receipts (GRN)" actions={<Button onClick={() => setOpen(true)}><Plus className="mr-1 h-4 w-4" /> New GRN</Button>} />
      <DataTable data={list.data} columns={[
        { header: "GRN No", cell: (r: any) => <span className="font-mono text-xs">{r.grn_no}</span> },
        { header: "Date", cell: (r: any) => fmtDate(r.receipt_date) },
        { header: "Supplier", cell: (r: any) => supName(r.supplier_id) },
        { header: "Status", cell: (r: any) => <span className="capitalize">{r.status}</span> },
        { header: "", cell: (r: any) => <Button size="icon" variant="ghost" onClick={() => del(r.id)}><Trash2 className="h-4 w-4" /></Button> },
      ]} />
      <CrudDialog title="New Goods Receipt" open={open} onOpenChange={setOpen} onSubmit={save}>
        <div className="grid gap-4 sm:grid-cols-2">
          <div><Label>Supplier *</Label>
            <Select value={hdr.supplier_id} onValueChange={(v) => setHdr({ ...hdr, supplier_id: v })}>
              <SelectTrigger><SelectValue placeholder="Select supplier" /></SelectTrigger>
              <SelectContent>{suppliers.data?.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div><Label>Warehouse *</Label>
            <Select value={hdr.warehouse_id} onValueChange={(v) => setHdr({ ...hdr, warehouse_id: v })}>
              <SelectTrigger><SelectValue placeholder="Select warehouse" /></SelectTrigger>
              <SelectContent>{warehouses.data?.map((w) => <SelectItem key={w.id} value={w.id}>{w.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div><Label>Receipt Date</Label><Input type="date" value={hdr.receipt_date} onChange={(e) => setHdr({ ...hdr, receipt_date: e.target.value })} /></div>
          <div className="sm:col-span-2"><Label>Notes</Label><Input value={hdr.notes} onChange={(e) => setHdr({ ...hdr, notes: e.target.value })} /></div>
        </div>
        <LineItemsEditor items={items} setItems={setItems} products={products.data ?? []} mode="purchase" />
      </CrudDialog>
    </>
  );
}
