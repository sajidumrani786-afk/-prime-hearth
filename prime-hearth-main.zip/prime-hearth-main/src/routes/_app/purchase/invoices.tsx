import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { PageHeader } from "@/components/erp/PageHeader";
import { DataTable } from "@/components/erp/DataTable";
import { CrudDialog } from "@/components/erp/CrudDialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useList } from "@/lib/crud";
import { fmtMoney, fmtDate, useSettings } from "@/lib/format";
import { LineItemsEditor, emptyLine, totals, type LineItem } from "@/components/erp/LineItemsEditor";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Plus, Trash2, Printer } from "lucide-react";
import { InvoicePrint } from "@/components/erp/print/InvoicePrint";

export const Route = createFileRoute("/_app/purchase/invoices")({ component: Page });

function Page() {
  const list = useList<any>("purchase_invoices", { order: "created_at" });
  const suppliers = useList<any>("suppliers", { order: "name", ascending: true });
  const products = useList<any>("products", { order: "name", ascending: true });
  const settings = useSettings();
  const sym = settings.data?.currency_symbol ?? "₹";
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [printId, setPrintId] = useState<string | null>(null);
  const [hdr, setHdr] = useState({ supplier_id: "", invoice_date: new Date().toISOString().slice(0, 10), due_date: "", discount: 0, notes: "" });
  const [items, setItems] = useState<LineItem[]>([emptyLine()]);
  const t = totals(items, hdr.discount);

  async function save() {
    if (!hdr.supplier_id) { toast.error("Supplier required"); return false; }
    const valid = items.filter((l) => l.product_id && l.qty > 0);
    if (!valid.length) { toast.error("Add lines"); return false; }
    const { data: pi, error } = await supabase.from("purchase_invoices").insert({
      supplier_id: hdr.supplier_id, invoice_date: hdr.invoice_date,
      due_date: hdr.due_date || null, discount: hdr.discount, notes: hdr.notes,
    }).select().single();
    if (error) { toast.error(error.message); return false; }
    const rows = valid.map((l) => ({ pi_id: pi.id, product_id: l.product_id, qty: l.qty, unit_price: l.unit_price, tax_rate: l.tax_rate, line_total: l.qty * l.unit_price * (1 + l.tax_rate / 100) }));
    const { error: e2 } = await supabase.from("purchase_invoice_items").insert(rows);
    if (e2) { toast.error(e2.message); return false; }
    const { error: e3 } = await supabase.rpc("finalize_purchase_invoice", { _pi_id: pi.id });
    if (e3) { toast.error(`Posted invoice but journal failed: ${e3.message}`); }
    else toast.success("Purchase Invoice posted with journal entry");
    qc.invalidateQueries({ queryKey: ["purchase_invoices", "list"] });
    setHdr({ supplier_id: "", invoice_date: new Date().toISOString().slice(0, 10), due_date: "", discount: 0, notes: "" });
    setItems([emptyLine()]);
  }

  async function del(id: string) {
    await supabase.from("journal_lines").delete().in("journal_id",
      (await supabase.from("journal_entries").select("id").eq("reference_type", "purchase_invoice").eq("reference_id", id)).data?.map((j: any) => j.id) ?? []);
    await supabase.from("journal_entries").delete().eq("reference_type", "purchase_invoice").eq("reference_id", id);
    await supabase.from("purchase_invoice_items").delete().eq("pi_id", id);
    const { error } = await supabase.from("purchase_invoices").delete().eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["purchase_invoices", "list"] });
  }
  const supName = (id: string) => suppliers.data?.find((s) => s.id === id)?.name ?? "—";

  return (
    <>
      <PageHeader title="Purchase Invoices" actions={<Button onClick={() => setOpen(true)}><Plus className="mr-1 h-4 w-4" /> New PI</Button>} />
      <DataTable data={list.data} columns={[
        { header: "PI No", cell: (r: any) => <span className="font-mono text-xs">{r.pi_no}</span> },
        { header: "Date", cell: (r: any) => fmtDate(r.invoice_date) },
        { header: "Supplier", cell: (r: any) => supName(r.supplier_id) },
        { header: "Total", cell: (r: any) => fmtMoney(r.total, sym), className: "text-right" },
        { header: "Paid", cell: (r: any) => fmtMoney(r.paid_amount, sym), className: "text-right" },
        { header: "Due", cell: (r: any) => fmtMoney(Number(r.total) - Number(r.paid_amount), sym), className: "text-right" },
        { header: "", cell: (r: any) => (
          <div className="flex justify-end gap-1">
            <Button size="icon" variant="ghost" onClick={() => setPrintId(r.id)}><Printer className="h-4 w-4" /></Button>
            <Button size="icon" variant="ghost" onClick={() => del(r.id)}><Trash2 className="h-4 w-4" /></Button>
          </div>
        ) },
      ]} />
      <InvoicePrint open={!!printId} onOpenChange={(v) => !v && setPrintId(null)} invoiceId={printId} mode="purchase" />
      <CrudDialog title="New Purchase Invoice" open={open} onOpenChange={setOpen} onSubmit={save}>
        <div className="grid gap-4 sm:grid-cols-2">
          <div><Label>Supplier *</Label>
            <Select value={hdr.supplier_id} onValueChange={(v) => setHdr({ ...hdr, supplier_id: v })}>
              <SelectTrigger><SelectValue placeholder="Select supplier" /></SelectTrigger>
              <SelectContent>{suppliers.data?.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div><Label>Invoice Date</Label><Input type="date" value={hdr.invoice_date} onChange={(e) => setHdr({ ...hdr, invoice_date: e.target.value })} /></div>
          <div><Label>Due Date</Label><Input type="date" value={hdr.due_date} onChange={(e) => setHdr({ ...hdr, due_date: e.target.value })} /></div>
          <div><Label>Discount</Label><Input type="number" value={hdr.discount} onChange={(e) => setHdr({ ...hdr, discount: +e.target.value })} /></div>
          <div className="sm:col-span-2"><Label>Notes</Label><Input value={hdr.notes} onChange={(e) => setHdr({ ...hdr, notes: e.target.value })} /></div>
        </div>
        <LineItemsEditor items={items} setItems={setItems} products={products.data ?? []} mode="purchase" sym={sym} />
        <div className="flex justify-end text-sm">
          <div className="space-y-1 text-right">
            <div>Subtotal: <span className="font-medium">{fmtMoney(t.subtotal, sym)}</span></div>
            <div>Tax: <span className="font-medium">{fmtMoney(t.tax, sym)}</span></div>
            <div>Discount: <span className="font-medium">{fmtMoney(hdr.discount, sym)}</span></div>
            <div className="text-base">Total: <span className="font-bold">{fmtMoney(t.total, sym)}</span></div>
          </div>
        </div>
      </CrudDialog>
    </>
  );
}
