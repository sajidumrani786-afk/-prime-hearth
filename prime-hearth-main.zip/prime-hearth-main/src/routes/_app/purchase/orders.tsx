import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { PageHeader } from "@/components/erp/PageHeader";
import { DataTable } from "@/components/erp/DataTable";
import { CrudDialog } from "@/components/erp/CrudDialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useList } from "@/lib/crud";
import { fmtMoney, fmtDate, useSettings } from "@/lib/format";
import { LineItemsEditor, emptyLine, totals, type LineItem } from "@/components/erp/LineItemsEditor";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Plus, Trash2 } from "lucide-react";

export const Route = createFileRoute("/_app/purchase/orders")({ component: Page });

function Page() {
  const list = useList<any>("purchase_orders", { order: "created_at" });
  const suppliers = useList<any>("suppliers", { order: "name", ascending: true });
  const warehouses = useList<any>("warehouses", { order: "name", ascending: true });
  const products = useList<any>("products", { order: "name", ascending: true });
  const settings = useSettings();
  const sym = settings.data?.currency_symbol ?? "₹";
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [hdr, setHdr] = useState({ supplier_id: "", warehouse_id: "", order_date: new Date().toISOString().slice(0, 10), expected_date: "", notes: "" });
  const [items, setItems] = useState<LineItem[]>([emptyLine()]);

  const t = totals(items);

  async function save() {
    if (!hdr.supplier_id || !hdr.warehouse_id) { toast.error("Supplier & warehouse required"); return false; }
    const valid = items.filter((l) => l.product_id && l.qty > 0);
    if (valid.length === 0) { toast.error("Add at least one line"); return false; }
    const { data: po, error } = await supabase.from("purchase_orders").insert({
      supplier_id: hdr.supplier_id, warehouse_id: hdr.warehouse_id,
      order_date: hdr.order_date, expected_date: hdr.expected_date || null,
      notes: hdr.notes, subtotal: t.subtotal, tax_total: t.tax, total: t.total, status: "confirmed",
    }).select().single();
    if (error) { toast.error(error.message); return false; }
    const lineRows = valid.map((l) => ({ po_id: po.id, product_id: l.product_id, qty: l.qty, unit_price: l.unit_price, tax_rate: l.tax_rate, line_total: l.qty * l.unit_price * (1 + l.tax_rate / 100) }));
    const { error: e2 } = await supabase.from("purchase_order_items").insert(lineRows);
    if (e2) { toast.error(e2.message); return false; }
    toast.success("Purchase Order created");
    qc.invalidateQueries({ queryKey: ["purchase_orders", "list"] });
    setHdr({ supplier_id: "", warehouse_id: "", order_date: new Date().toISOString().slice(0, 10), expected_date: "", notes: "" });
    setItems([emptyLine()]);
  }

  async function del(id: string) {
    await supabase.from("purchase_order_items").delete().eq("po_id", id);
    const { error } = await supabase.from("purchase_orders").delete().eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["purchase_orders", "list"] });
  }

  const supName = (id: string) => suppliers.data?.find((s) => s.id === id)?.name ?? "—";

  return (
    <>
      <PageHeader title="Purchase Orders" actions={<Button onClick={() => setOpen(true)}><Plus className="mr-1 h-4 w-4" /> New PO</Button>} />
      <DataTable data={list.data} columns={[
        { header: "PO No", cell: (r: any) => <span className="font-mono text-xs">{r.po_no}</span> },
        { header: "Date", cell: (r: any) => fmtDate(r.order_date) },
        { header: "Supplier", cell: (r: any) => supName(r.supplier_id) },
        { header: "Status", cell: (r: any) => <span className="capitalize">{r.status}</span> },
        { header: "Total", cell: (r: any) => fmtMoney(r.total, sym), className: "text-right" },
        { header: "", cell: (r: any) => <Button size="icon" variant="ghost" onClick={() => del(r.id)}><Trash2 className="h-4 w-4" /></Button> },
      ]} />
      <CrudDialog title="New Purchase Order" open={open} onOpenChange={setOpen} onSubmit={save}>
        <div className="grid gap-4 sm:grid-cols-2">
          <div><Label>Supplier *</Label>
            <Select value={hdr.supplier_id} onValueChange={(v) => setHdr({ ...hdr, supplier_id: v })}>
              <SelectTrigger><SelectValue placeholder="Select supplier" /></SelectTrigger>
              <SelectContent>{suppliers.data?.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div><Label>Warehouse *</Label>
            <Select value={hdr.warehouse_id} onValueChange={(v) => setHdr({ ...hdr, warehouse_id: v })}>
              <SelectTrigger><SelectValue placeholder="Select warehouse" /></SelectTrigger>
              <SelectContent>{warehouses.data?.map((w) => <SelectItem key={w.id} value={w.id}>{w.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div><Label>Order Date</Label><Input type="date" value={hdr.order_date} onChange={(e) => setHdr({ ...hdr, order_date: e.target.value })} /></div>
          <div><Label>Expected Date</Label><Input type="date" value={hdr.expected_date} onChange={(e) => setHdr({ ...hdr, expected_date: e.target.value })} /></div>
          <div className="sm:col-span-2"><Label>Notes</Label><Input value={hdr.notes} onChange={(e) => setHdr({ ...hdr, notes: e.target.value })} /></div>
        </div>
        <LineItemsEditor items={items} setItems={setItems} products={products.data ?? []} mode="purchase" sym={sym} />
        <div className="flex justify-end text-sm">
          <div className="space-y-1 text-right">
            <div>Subtotal: <span className="font-medium">{fmtMoney(t.subtotal, sym)}</span></div>
            <div>Tax: <span className="font-medium">{fmtMoney(t.tax, sym)}</span></div>
            <div className="text-base">Total: <span className="font-bold">{fmtMoney(t.total, sym)}</span></div>
          </div>
        </div>
      </CrudDialog>
    </>
  );
}
