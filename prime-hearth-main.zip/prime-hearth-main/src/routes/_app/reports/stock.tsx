import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { PageHeader } from "@/components/erp/PageHeader";
import { supabase } from "@/integrations/supabase/client";
import { fmtMoney, useSettings } from "@/lib/format";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export const Route = createFileRoute("/_app/reports/stock")({ component: Page });

function Page() {
  const settings = useSettings();
  const sym = settings.data?.currency_symbol ?? "₹";
  const q = useQuery({
    queryKey: ["stock-report"],
    queryFn: async () => {
      const { data: products } = await supabase.from("products").select("*");
      const { data: moves } = await supabase.from("inventory_movements").select("product_id, warehouse_id, movement_type, qty, unit_cost");
      const { data: warehouses } = await supabase.from("warehouses").select("*");
      const whMap = new Map((warehouses ?? []).map((w: any) => [w.id, w]));
      type Row = { product: any; warehouse: any; qty: number; value: number };
      const map = new Map<string, Row>();
      (moves ?? []).forEach((m: any) => {
        const key = `${m.product_id}:${m.warehouse_id}`;
        const r = map.get(key) ?? { product: (products ?? []).find((p: any) => p.id === m.product_id), warehouse: whMap.get(m.warehouse_id), qty: 0, value: 0 };
        const sign = m.movement_type === "in" ? 1 : -1;
        r.qty += sign * Number(m.qty);
        r.value += sign * Number(m.qty) * Number(m.unit_cost);
        map.set(key, r);
      });
      return Array.from(map.values()).filter((r) => r.product).sort((a, b) => (a.product?.name ?? "").localeCompare(b.product?.name ?? ""));
    },
  });

  const totalValue = (q.data ?? []).reduce((s, r) => s + r.value, 0);

  return (
    <>
      <PageHeader title="Stock Report" description="On-hand inventory by product & warehouse" />
      <div className="rounded-lg border bg-card">
        <Table>
          <TableHeader><TableRow>
            <TableHead>SKU</TableHead><TableHead>Product</TableHead><TableHead>Warehouse</TableHead>
            <TableHead className="text-right">Qty</TableHead><TableHead className="text-right">Value</TableHead>
          </TableRow></TableHeader>
          <TableBody>
            {q.data?.map((r, i) => (
              <TableRow key={i}>
                <TableCell className="font-mono text-xs">{r.product?.sku}</TableCell>
                <TableCell>{r.product?.name}</TableCell>
                <TableCell>{r.warehouse?.name ?? "—"}</TableCell>
                <TableCell className="text-right">{r.qty}</TableCell>
                <TableCell className="text-right">{fmtMoney(r.value, sym)}</TableCell>
              </TableRow>
            ))}
            {!q.data?.length && <TableRow><TableCell colSpan={5} className="py-10 text-center text-sm text-muted-foreground">No stock movements yet.</TableCell></TableRow>}
            <TableRow className="font-bold border-t-2"><TableCell colSpan={4}>Total Inventory Value</TableCell><TableCell className="text-right">{fmtMoney(totalValue, sym)}</TableCell></TableRow>
          </TableBody>
        </Table>
      </div>
    </>
  );
}
