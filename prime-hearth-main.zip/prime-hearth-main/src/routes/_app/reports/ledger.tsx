import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { PageHeader } from "@/components/erp/PageHeader";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { fmtMoney, fmtDate, useSettings } from "@/lib/format";
import { useList } from "@/lib/crud";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Printer } from "lucide-react";
import { LedgerPrint } from "@/components/erp/print/LedgerPrint";

export const Route = createFileRoute("/_app/reports/ledger")({ component: Page });

function Page() {
  const accounts = useList<any>("accounts", { order: "code", ascending: true });
  const [accId, setAccId] = useState("");
  const [printOpen, setPrintOpen] = useState(false);
  const settings = useSettings();
  const sym = settings.data?.currency_symbol ?? "₹";

  const q = useQuery({
    queryKey: ["ledger", accId],
    enabled: !!accId,
    queryFn: async () => {
      const { data: lines } = await supabase.from("journal_lines").select("*, journal:journal_entries(entry_no, entry_date, narration)").eq("account_id", accId);
      return (lines ?? []).sort((a: any, b: any) => (a.journal?.entry_date < b.journal?.entry_date ? -1 : 1));
    },
  });

  let bal = 0;
  const account = accounts.data?.find((a) => a.id === accId) ?? null;
  return (
    <>
      <PageHeader title="Ledger" description="Account-wise transaction history with running balance" />
      <div className="mb-4 flex items-end gap-3">
        <div className="max-w-md flex-1">
          <Label>Account</Label>
          <Select value={accId} onValueChange={setAccId}>
            <SelectTrigger><SelectValue placeholder="Select account" /></SelectTrigger>
            <SelectContent>{accounts.data?.map((a) => <SelectItem key={a.id} value={a.id}>{a.code} — {a.name}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        {accId && (
          <Button variant="outline" onClick={() => setPrintOpen(true)}>
            <Printer className="mr-1 h-4 w-4" /> Print Ledger
          </Button>
        )}
      </div>
      {accId && (
        <div className="rounded-lg border bg-card">
          <Table>
            <TableHeader><TableRow>
              <TableHead>Date</TableHead><TableHead>Entry</TableHead><TableHead>Narration</TableHead>
              <TableHead className="text-right">Debit</TableHead><TableHead className="text-right">Credit</TableHead><TableHead className="text-right">Balance</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {q.data?.map((l: any) => {
                bal += Number(l.debit) - Number(l.credit);
                return (
                  <TableRow key={l.id}>
                    <TableCell>{fmtDate(l.journal?.entry_date)}</TableCell>
                    <TableCell className="font-mono text-xs">{l.journal?.entry_no}</TableCell>
                    <TableCell>{l.journal?.narration}{l.description && ` — ${l.description}`}</TableCell>
                    <TableCell className="text-right">{Number(l.debit) > 0 ? fmtMoney(l.debit, sym) : ""}</TableCell>
                    <TableCell className="text-right">{Number(l.credit) > 0 ? fmtMoney(l.credit, sym) : ""}</TableCell>
                    <TableCell className="text-right font-medium">{fmtMoney(bal, sym)}</TableCell>
                  </TableRow>
                );
              })}
              {!q.data?.length && <TableRow><TableCell colSpan={6} className="py-10 text-center text-sm text-muted-foreground">No transactions.</TableCell></TableRow>}
            </TableBody>
          </Table>
        </div>
      )}
      <LedgerPrint open={printOpen} onOpenChange={setPrintOpen} account={account} lines={q.data ?? []} />
    </>
  );
}
