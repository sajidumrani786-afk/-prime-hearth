import { createFileRoute } from "@tanstack/react-router";
import { ComingSoon } from "@/components/erp/ComingSoon";

export const Route = createFileRoute("/_app/reports/balance-sheet")({
  component: () => <ComingSoon title="reports/balance-sheet" description="Module page" />,
});
