import { createFileRoute } from "@tanstack/react-router";
import { ComingSoon } from "@/components/erp/ComingSoon";

export const Route = createFileRoute("/_app/reports/pl")({
  component: () => <ComingSoon title="reports/pl" description="Module page" />,
});
