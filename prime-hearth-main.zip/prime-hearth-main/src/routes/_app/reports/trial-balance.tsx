import { createFileRoute } from "@tanstack/react-router";
import { ComingSoon } from "@/components/erp/ComingSoon";

export const Route = createFileRoute("/_app/reports/trial-balance")({
  component: () => <ComingSoon title="reports/trial-balance" description="Module page" />,
});
