import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader } from "@/components/erp/PageHeader";
import { DataTable } from "@/components/erp/DataTable";
import { CrudDialog } from "@/components/erp/CrudDialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useList, useUpsert, useDelete } from "@/lib/crud";
import { fmtMoney, useSettings } from "@/lib/format";
import { Plus, Trash2 } from "lucide-react";

export const Route = createFileRoute("/_app/master/products")({ component: ProductsPage });

function ProductsPage() {
  const list = useList<any>("products", { order: "created_at" });
  const upsert = useUpsert("products");
  const del = useDelete("products");
  const settings = useSettings();
  const sym = settings.data?.currency_symbol ?? "₹";
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ sku: "", name: "", unit: "PCS", purchase_price: 0, sale_price: 0, tax_rate: 12, hsn_code: "" });

  return (
    <>
      <PageHeader
        title="Products"
        description="Manage your product / medicine catalog"
        actions={<Button onClick={() => setOpen(true)}><Plus className="mr-1 h-4 w-4" /> New Product</Button>}
      />
      <DataTable
        data={list.data}
        columns={[
          { header: "SKU", cell: (r) => <span className="font-mono text-xs">{r.sku}</span> },
          { header: "Name", cell: (r) => r.name },
          { header: "Unit", cell: (r) => r.unit },
          { header: "Purchase", cell: (r) => fmtMoney(r.purchase_price, sym), className: "text-right" },
          { header: "Sale", cell: (r) => fmtMoney(r.sale_price, sym), className: "text-right" },
          { header: "Tax %", cell: (r) => `${r.tax_rate}%`, className: "text-right" },
          { header: "", cell: (r) => (
            <Button size="icon" variant="ghost" onClick={() => del.mutate(r.id)}><Trash2 className="h-4 w-4" /></Button>
          ), className: "w-10" },
        ]}
      />
      <CrudDialog
        title="New Product"
        open={open}
        onOpenChange={setOpen}
        onSubmit={async () => {
          if (!form.sku || !form.name) return false;
          await upsert.mutateAsync(form);
          setForm({ sku: "", name: "", unit: "PCS", purchase_price: 0, sale_price: 0, tax_rate: 12, hsn_code: "" });
        }}
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <div><Label>SKU *</Label><Input value={form.sku} onChange={(e) => setForm({ ...form, sku: e.target.value })} /></div>
          <div><Label>Name *</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
          <div><Label>Unit</Label><Input value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })} /></div>
          <div><Label>HSN Code</Label><Input value={form.hsn_code} onChange={(e) => setForm({ ...form, hsn_code: e.target.value })} /></div>
          <div><Label>Purchase Price</Label><Input type="number" value={form.purchase_price} onChange={(e) => setForm({ ...form, purchase_price: +e.target.value })} /></div>
          <div><Label>Sale Price</Label><Input type="number" value={form.sale_price} onChange={(e) => setForm({ ...form, sale_price: +e.target.value })} /></div>
          <div><Label>Tax Rate %</Label><Input type="number" value={form.tax_rate} onChange={(e) => setForm({ ...form, tax_rate: +e.target.value })} /></div>
        </div>
      </CrudDialog>
    </>
  );
}