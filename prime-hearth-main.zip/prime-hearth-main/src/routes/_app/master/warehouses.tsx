import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader } from "@/components/erp/PageHeader";
import { DataTable } from "@/components/erp/DataTable";
import { CrudDialog } from "@/components/erp/CrudDialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useList, useUpsert, useDelete } from "@/lib/crud";
import { Plus, Trash2 } from "lucide-react";

export const Route = createFileRoute("/_app/master/warehouses")({ component: Page });

function Page() {
  const list = useList<any>("warehouses", { order: "created_at" });
  const upsert = useUpsert("warehouses");
  const del = useDelete("warehouses");
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ code: "", name: "", address: "" });
  return (
    <>
      <PageHeader title="Warehouses" actions={<Button onClick={() => setOpen(true)}><Plus className="mr-1 h-4 w-4" /> New Warehouse</Button>} />
      <DataTable data={list.data} columns={[
        { header: "Code", cell: (r: any) => r.code },
        { header: "Name", cell: (r: any) => r.name },
        { header: "Address", cell: (r: any) => r.address ?? "—" },
        { header: "", cell: (r: any) => <Button size="icon" variant="ghost" onClick={() => del.mutate(r.id)}><Trash2 className="h-4 w-4" /></Button> },
      ]} />
      <CrudDialog title="New Warehouse" open={open} onOpenChange={setOpen}
        onSubmit={async () => { if (!f.code || !f.name) return false; await upsert.mutateAsync(f); setF({ code: "", name: "", address: "" }); }}>
        <div className="grid gap-4 sm:grid-cols-2">
          <div><Label>Code *</Label><Input value={f.code} onChange={(e) => setF({ ...f, code: e.target.value })} /></div>
          <div><Label>Name *</Label><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></div>
          <div className="sm:col-span-2"><Label>Address</Label><Input value={f.address} onChange={(e) => setF({ ...f, address: e.target.value })} /></div>
        </div>
      </CrudDialog>
    </>
  );
}
