import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader } from "@/components/erp/PageHeader";
import { fmtMoney, useSettings } from "@/lib/format";
import { DollarSign, ShoppingBag, Users, Truck, AlertTriangle } from "lucide-react";

export const Route = createFileRoute("/_app/dashboard")({ component: Dashboard });

function Dashboard() {
  const settings = useSettings();
  const sym = settings.data?.currency_symbol ?? "₹";

  const kpis = useQuery({
    queryKey: ["dashboard-kpis"],
    queryFn: async () => {
      const [si, pi, customers, suppliers, products, ar, ap] = await Promise.all([
        supabase.from("sales_invoices").select("total, paid_amount"),
        supabase.from("purchase_invoices").select("total, paid_amount"),
        supabase.from("customers").select("id", { count: "exact", head: true }),
        supabase.from("suppliers").select("id", { count: "exact", head: true }),
        supabase.from("products").select("id", { count: "exact", head: true }),
        supabase.from("sales_invoices").select("total, paid_amount"),
        supabase.from("purchase_invoices").select("total, paid_amount"),
      ]);
      const sum = (rows: any[] | null, k: string) => (rows ?? []).reduce((s, r) => s + Number(r[k] ?? 0), 0);
      return {
        sales_total: sum(si.data, "total"),
        purchase_total: sum(pi.data, "total"),
        customers: customers.count ?? 0,
        suppliers: suppliers.count ?? 0,
        products: products.count ?? 0,
        ar: sum(ar.data, "total") - sum(ar.data, "paid_amount"),
        ap: sum(ap.data, "total") - sum(ap.data, "paid_amount"),
      };
    },
  });

  const stats = [
    { label: "Total Sales", value: fmtMoney(kpis.data?.sales_total, sym), icon: DollarSign },
    { label: "Total Purchases", value: fmtMoney(kpis.data?.purchase_total, sym), icon: ShoppingBag },
    { label: "Receivable (AR)", value: fmtMoney(kpis.data?.ar, sym), icon: Users },
    { label: "Payable (AP)", value: fmtMoney(kpis.data?.ap, sym), icon: Truck },
  ];

  return (
    <>
      <PageHeader title="Dashboard" description="Real-time overview of your ERP" />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => {
          const Icon = s.icon;
          return (
            <Card key={s.label}>
              <CardContent className="flex items-center justify-between p-5">
                <div>
                  <div className="text-sm text-muted-foreground">{s.label}</div>
                  <div className="mt-1 text-2xl font-bold">{s.value}</div>
                </div>
                <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary">
                  <Icon className="h-5 w-5" />
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
      <div className="mt-6 grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader><CardTitle>Customers</CardTitle></CardHeader>
          <CardContent className="text-3xl font-bold">{kpis.data?.customers ?? 0}</CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Suppliers</CardTitle></CardHeader>
          <CardContent className="text-3xl font-bold">{kpis.data?.suppliers ?? 0}</CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Products</CardTitle></CardHeader>
          <CardContent className="text-3xl font-bold">{kpis.data?.products ?? 0}</CardContent>
        </Card>
      </div>
      <Card className="mt-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><AlertTriangle className="h-4 w-4" /> Quick start</CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground space-y-2">
          <p>1. Add Suppliers and Customers in Master Data.</p>
          <p>2. Create Products with purchase/sale prices.</p>
          <p>3. Run a Purchase Order → Goods Receipt → Purchase Invoice → Payment.</p>
          <p>4. Run a Sales Order → Delivery → Sales Invoice → Payment.</p>
          <p>5. View ledgers, trial balance, P&amp;L and balance sheet — generated automatically from journal entries.</p>
        </CardContent>
      </Card>
    </>
  );
}