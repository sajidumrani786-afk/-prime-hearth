const ones = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"];
const tens = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];

function twoDigit(n: number): string {
  if (n < 20) return ones[n];
  const t = Math.floor(n / 10), o = n % 10;
  return tens[t] + (o ? " " + ones[o] : "");
}
function threeDigit(n: number): string {
  const h = Math.floor(n / 100), r = n % 100;
  let s = "";
  if (h) s += ones[h] + " Hundred";
  if (r) s += (s ? " " : "") + twoDigit(r);
  return s;
}

export function numberToWords(num: number, currency = "Rupees", fraction = "Paise"): string {
  if (num == null || isNaN(num)) return "";
  const negative = num < 0;
  num = Math.abs(num);
  const whole = Math.floor(num);
  const frac = Math.round((num - whole) * 100);

  if (whole === 0 && frac === 0) return `${currency} Zero Only`;

  // Indian numbering: Crore, Lakh, Thousand, Hundred
  const crore = Math.floor(whole / 10000000);
  const lakh = Math.floor((whole % 10000000) / 100000);
  const thousand = Math.floor((whole % 100000) / 1000);
  const rest = whole % 1000;

  const parts: string[] = [];
  if (crore) parts.push(twoDigit(crore) + " Crore");
  if (lakh) parts.push(twoDigit(lakh) + " Lakh");
  if (thousand) parts.push(twoDigit(thousand) + " Thousand");
  if (rest) parts.push(threeDigit(rest));

  let words = parts.join(" ").trim();
  if (!words) words = "Zero";
  let result = `${currency} ${words}`;
  if (frac) result += ` and ${twoDigit(frac)} ${fraction}`;
  result += " Only";
  return (negative ? "Minus " : "") + result;
}