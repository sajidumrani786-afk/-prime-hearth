import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export function useList<T = any>(table: string, opts?: { order?: string; ascending?: boolean }) {
  return useQuery<T[]>({
    queryKey: [table, "list"],
    queryFn: async () => {
      let q: any = supabase.from(table as any).select("*");
      if (opts?.order) q = q.order(opts.order, { ascending: opts.ascending ?? false });
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as T[];
    },
  });
}

export function useUpsert(table: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (payload: any) => {
      const { data, error } = await supabase.from(table as any).insert(payload).select().single();
      if (error) throw error;
      return data;
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: [table, "list"] }); toast.success("Saved"); },
    onError: (e: any) => toast.error(e.message),
  });
}

export function useDelete(table: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from(table as any).delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: [table, "list"] }); toast.success("Deleted"); },
    onError: (e: any) => toast.error(e.message),
  });
}
