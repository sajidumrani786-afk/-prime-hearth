import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface CompanySettings {
  company_name: string;
  currency_code: string;
  currency_symbol: string;
  tax_mode: string;
  default_tax_rate: number;
  fiscal_year_start_month: number;
}

export function useSettings() {
  return useQuery<CompanySettings>({
    queryKey: ["company_settings"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("company_settings")
        .select("*")
        .eq("id", 1)
        .single();
      if (error) throw error;
      return data as any;
    },
    staleTime: 60_000,
  });
}

export function fmtMoney(v: number | string | null | undefined, sym = "₹") {
  const n = Number(v ?? 0);
  return `${sym}${n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export function fmtDate(d: string | Date | null | undefined) {
  if (!d) return "—";
  return new Date(d).toLocaleDateString();
}