import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Printer, X } from "lucide-react";
import { type ReactNode } from "react";

export function PrintFrame({
  open,
  onOpenChange,
  children,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  children: ReactNode;
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl p-0 sm:max-w-4xl">
        <div className="no-print flex items-center justify-between border-b bg-muted/40 px-4 py-2">
          <div className="text-sm font-medium">Document Preview</div>
          <div className="flex gap-2">
            <Button size="sm" onClick={() => window.print()}><Printer className="mr-1 h-4 w-4" /> Print</Button>
            <Button size="sm" variant="ghost" onClick={() => onOpenChange(false)}><X className="h-4 w-4" /></Button>
          </div>
        </div>
        <div className="print-area max-h-[80vh] overflow-auto bg-white p-8 text-black">
          {children}
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function CompanyHeader({ company, title, docNo, docDate, dueDate }: {
  company: any; title: string; docNo?: string; docDate?: string; dueDate?: string;
}) {
  return (
    <div className="flex items-start justify-between border-b-2 border-gray-800 pb-4">
      <div>
        <h1 className="text-2xl font-bold">{company?.company_name ?? "Company"}</h1>
        <p className="text-xs text-gray-600">Tax Mode: {company?.tax_mode ?? "—"} • Currency: {company?.currency_code}</p>
      </div>
      <div className="text-right">
        <h2 className="text-xl font-bold uppercase tracking-wide">{title}</h2>
        {docNo && <p className="mt-1 text-sm"><span className="text-gray-600">No: </span><span className="font-mono">{docNo}</span></p>}
        {docDate && <p className="text-sm"><span className="text-gray-600">Date: </span>{docDate}</p>}
        {dueDate && <p className="text-sm"><span className="text-gray-600">Due: </span>{dueDate}</p>}
      </div>
    </div>
  );
}

export function PartyBlock({ title, party }: { title: string; party: any }) {
  if (!party) return null;
  return (
    <div className="text-sm">
      <p className="mb-1 text-xs font-semibold uppercase text-gray-600">{title}</p>
      <p className="font-semibold">{party.name}</p>
      {party.address && <p className="whitespace-pre-line text-xs">{party.address}</p>}
      {party.phone && <p className="text-xs">Phone: {party.phone}</p>}
      {party.email && <p className="text-xs">Email: {party.email}</p>}
      {party.gstin && <p className="text-xs">GSTIN: {party.gstin}</p>}
    </div>
  );
}