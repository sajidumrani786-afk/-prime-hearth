import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { fmtMoney, fmtDate, useSettings } from "@/lib/format";
import { numberToWords } from "@/lib/numberToWords";
import { PrintFrame, CompanyHeader, PartyBlock } from "./PrintFrame";

export function InvoicePrint({
  open, onOpenChange, invoiceId, mode,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  invoiceId: string | null;
  mode: "purchase" | "sales";
}) {
  const settings = useSettings();
  const sym = settings.data?.currency_symbol ?? "₹";
  const currencyName = settings.data?.currency_code === "INR" ? "Rupees" : settings.data?.currency_code ?? "";

  const table = mode === "purchase" ? "purchase_invoices" : "sales_invoices";
  const itemsTable = mode === "purchase" ? "purchase_invoice_items" : "sales_invoice_items";
  const fk = mode === "purchase" ? "pi_id" : "si_id";
  const partyTable = mode === "purchase" ? "suppliers" : "customers";
  const partyFk = mode === "purchase" ? "supplier_id" : "customer_id";
  const docNoField = mode === "purchase" ? "pi_no" : "si_no";

  const q = useQuery({
    queryKey: ["invoice-print", mode, invoiceId],
    enabled: !!invoiceId && open,
    queryFn: async () => {
      const { data: inv } = await supabase.from(table as any).select("*").eq("id", invoiceId!).single();
      const { data: items } = await supabase.from(itemsTable as any).select("*, product:products(sku, name, hsn_code, unit)").eq(fk, invoiceId!);
      const { data: party } = await supabase.from(partyTable as any).select("*").eq("id", (inv as any)?.[partyFk]).single();
      return { inv, items: items ?? [], party };
    },
  });

  const inv: any = q.data?.inv;
  const items: any[] = q.data?.items ?? [];
  const party = q.data?.party;
  const subtotal = items.reduce((s, l) => s + Number(l.qty) * Number(l.unit_price), 0);
  const tax = items.reduce((s, l) => s + Number(l.qty) * Number(l.unit_price) * Number(l.tax_rate) / 100, 0);
  const discount = Number(inv?.discount ?? 0);
  const total = Number(inv?.total ?? subtotal + tax - discount);

  return (
    <PrintFrame open={open} onOpenChange={onOpenChange}>
      {!inv ? <p className="text-sm text-gray-500">Loading…</p> : (
        <div className="space-y-6 font-sans text-sm">
          <CompanyHeader
            company={settings.data}
            title={mode === "purchase" ? "Purchase Invoice" : "Tax Invoice"}
            docNo={inv[docNoField]}
            docDate={fmtDate(inv.invoice_date)}
            dueDate={inv.due_date ? fmtDate(inv.due_date) : undefined}
          />
          <div className="grid grid-cols-2 gap-6">
            <PartyBlock title={mode === "purchase" ? "Supplier" : "Bill To"} party={party} />
            <div className="text-right text-xs">
              <p><span className="text-gray-600">Status: </span><span className="capitalize font-medium">{inv.status}</span></p>
              <p><span className="text-gray-600">Paid: </span>{fmtMoney(inv.paid_amount, sym)}</p>
              <p><span className="text-gray-600">Balance Due: </span><span className="font-semibold">{fmtMoney(total - Number(inv.paid_amount), sym)}</span></p>
            </div>
          </div>

          <table className="w-full border-collapse text-xs">
            <thead>
              <tr className="border-y-2 border-gray-800 bg-gray-100 text-left">
                <th className="py-2 px-2 w-8">#</th>
                <th className="py-2 px-2">Item Description</th>
                <th className="py-2 px-2">HSN</th>
                <th className="py-2 px-2 text-right">Qty</th>
                <th className="py-2 px-2 text-right">Rate</th>
                <th className="py-2 px-2 text-right">Tax%</th>
                <th className="py-2 px-2 text-right">Amount</th>
              </tr>
            </thead>
            <tbody>
              {items.map((l, i) => {
                const amt = Number(l.qty) * Number(l.unit_price) * (1 + Number(l.tax_rate) / 100);
                return (
                  <tr key={l.id} className="border-b border-gray-300">
                    <td className="py-2 px-2">{i + 1}</td>
                    <td className="py-2 px-2">
                      <div className="font-medium">{l.product?.name}</div>
                      <div className="text-[10px] text-gray-500">SKU: {l.product?.sku}</div>
                    </td>
                    <td className="py-2 px-2">{l.product?.hsn_code ?? "—"}</td>
                    <td className="py-2 px-2 text-right">{Number(l.qty).toFixed(2)} {l.product?.unit}</td>
                    <td className="py-2 px-2 text-right">{fmtMoney(l.unit_price, sym)}</td>
                    <td className="py-2 px-2 text-right">{Number(l.tax_rate).toFixed(1)}%</td>
                    <td className="py-2 px-2 text-right">{fmtMoney(amt, sym)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          <div className="flex justify-end">
            <table className="text-xs">
              <tbody>
                <tr><td className="px-3 py-1 text-gray-600">Subtotal</td><td className="px-3 py-1 text-right font-medium">{fmtMoney(subtotal, sym)}</td></tr>
                <tr><td className="px-3 py-1 text-gray-600">Tax</td><td className="px-3 py-1 text-right font-medium">{fmtMoney(tax, sym)}</td></tr>
                <tr><td className="px-3 py-1 text-gray-600">Discount</td><td className="px-3 py-1 text-right font-medium">- {fmtMoney(discount, sym)}</td></tr>
                <tr className="border-t-2 border-gray-800"><td className="px-3 py-2 font-bold">Grand Total</td><td className="px-3 py-2 text-right text-base font-bold">{fmtMoney(total, sym)}</td></tr>
              </tbody>
            </table>
          </div>

          <div className="border-t border-gray-300 pt-3 text-xs">
            <p className="text-gray-600">Amount in words:</p>
            <p className="font-medium italic">{numberToWords(total, currencyName)}</p>
          </div>

          {inv.notes && (
            <div className="text-xs">
              <p className="font-semibold text-gray-600">Notes:</p>
              <p className="whitespace-pre-line">{inv.notes}</p>
            </div>
          )}

          <div className="grid grid-cols-2 gap-6 pt-12 text-xs">
            <div>
              <p className="font-semibold">Terms &amp; Conditions:</p>
              <p className="text-gray-600">Payment due by the date mentioned above. Goods once sold will not be taken back.</p>
            </div>
            <div className="text-right">
              <div className="mt-10 border-t border-gray-400 pt-1">Authorised Signatory</div>
              <div className="text-[10px] text-gray-500">For {settings.data?.company_name}</div>
            </div>
          </div>
        </div>
      )}
    </PrintFrame>
  );
}