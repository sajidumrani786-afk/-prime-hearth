import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { fmtDate, useSettings } from "@/lib/format";
import { PrintFrame, CompanyHeader, PartyBlock } from "./PrintFrame";

export function DeliveryPrint({
  open, onOpenChange, deliveryId,
}: {
  open: boolean; onOpenChange: (v: boolean) => void; deliveryId: string | null;
}) {
  const settings = useSettings();
  const q = useQuery({
    queryKey: ["delivery-print", deliveryId],
    enabled: !!deliveryId && open,
    queryFn: async () => {
      const { data: dlv } = await supabase.from("deliveries").select("*").eq("id", deliveryId!).single();
      const { data: items } = await supabase.from("delivery_items").select("*, product:products(sku, name, unit)").eq("delivery_id", deliveryId!);
      const { data: cust } = await supabase.from("customers").select("*").eq("id", (dlv as any)?.customer_id).single();
      const { data: wh } = await supabase.from("warehouses").select("*").eq("id", (dlv as any)?.warehouse_id).single();
      return { dlv, items: items ?? [], cust, wh };
    },
  });

  const dlv: any = q.data?.dlv;
  const items: any[] = q.data?.items ?? [];
  const totalQty = items.reduce((s, l) => s + Number(l.qty), 0);

  return (
    <PrintFrame open={open} onOpenChange={onOpenChange}>
      {!dlv ? <p className="text-sm text-gray-500">Loading…</p> : (
        <div className="space-y-6 font-sans text-sm">
          <CompanyHeader company={settings.data} title="Delivery Order" docNo={dlv.dlv_no} docDate={fmtDate(dlv.delivery_date)} />
          <div className="grid grid-cols-2 gap-6">
            <PartyBlock title="Deliver To" party={q.data?.cust} />
            <div className="text-right text-xs">
              <p><span className="text-gray-600">Warehouse: </span><span className="font-medium">{q.data?.wh?.name}</span></p>
              {q.data?.wh?.address && <p className="text-gray-500">{q.data?.wh?.address}</p>}
              <p className="mt-1"><span className="text-gray-600">Status: </span><span className="capitalize font-medium">{dlv.status}</span></p>
            </div>
          </div>

          <table className="w-full border-collapse text-xs">
            <thead>
              <tr className="border-y-2 border-gray-800 bg-gray-100 text-left">
                <th className="py-2 px-2 w-8">#</th>
                <th className="py-2 px-2">Item Description</th>
                <th className="py-2 px-2">SKU</th>
                <th className="py-2 px-2 text-right">Qty</th>
                <th className="py-2 px-2">Unit</th>
              </tr>
            </thead>
            <tbody>
              {items.map((l, i) => (
                <tr key={l.id} className="border-b border-gray-300">
                  <td className="py-2 px-2">{i + 1}</td>
                  <td className="py-2 px-2 font-medium">{l.product?.name}</td>
                  <td className="py-2 px-2">{l.product?.sku}</td>
                  <td className="py-2 px-2 text-right">{Number(l.qty).toFixed(2)}</td>
                  <td className="py-2 px-2">{l.product?.unit}</td>
                </tr>
              ))}
              <tr className="border-t-2 border-gray-800 font-semibold">
                <td colSpan={3} className="py-2 px-2 text-right">Total Quantity</td>
                <td className="py-2 px-2 text-right">{totalQty.toFixed(2)}</td>
                <td />
              </tr>
            </tbody>
          </table>

          {dlv.notes && (
            <div className="text-xs">
              <p className="font-semibold text-gray-600">Notes:</p>
              <p className="whitespace-pre-line">{dlv.notes}</p>
            </div>
          )}

          <div className="grid grid-cols-3 gap-6 pt-16 text-xs">
            <div className="text-center"><div className="border-t border-gray-400 pt-1">Prepared By</div></div>
            <div className="text-center"><div className="border-t border-gray-400 pt-1">Received By (Sign &amp; Date)</div></div>
            <div className="text-center"><div className="border-t border-gray-400 pt-1">Authorised Signatory</div></div>
          </div>
        </div>
      )}
    </PrintFrame>
  );
}