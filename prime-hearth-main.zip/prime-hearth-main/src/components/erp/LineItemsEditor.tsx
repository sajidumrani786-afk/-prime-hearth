import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Trash2, Plus } from "lucide-react";
import { fmtMoney } from "@/lib/format";

export interface LineItem {
  product_id: string;
  qty: number;
  unit_price: number;
  tax_rate: number;
}

export function emptyLine(): LineItem {
  return { product_id: "", qty: 1, unit_price: 0, tax_rate: 0 };
}

export function lineSubtotal(l: LineItem) { return l.qty * l.unit_price; }
export function lineTax(l: LineItem) { return lineSubtotal(l) * (l.tax_rate / 100); }
export function totals(items: LineItem[], discount = 0) {
  const subtotal = items.reduce((s, l) => s + lineSubtotal(l), 0);
  const tax = items.reduce((s, l) => s + lineTax(l), 0);
  return { subtotal, tax, total: subtotal + tax - discount };
}

export function LineItemsEditor({
  items, setItems, products, mode, sym = "₹",
}: {
  items: LineItem[];
  setItems: (i: LineItem[]) => void;
  products: any[];
  mode: "purchase" | "sales";
  sym?: string;
}) {
  const update = (idx: number, patch: Partial<LineItem>) => {
    const next = items.map((l, i) => (i === idx ? { ...l, ...patch } : l));
    setItems(next);
  };
  const onProduct = (idx: number, pid: string) => {
    const p = products.find((x) => x.id === pid);
    if (!p) return update(idx, { product_id: pid });
    update(idx, {
      product_id: pid,
      unit_price: mode === "purchase" ? Number(p.purchase_price) : Number(p.sale_price),
      tax_rate: Number(p.tax_rate ?? 0),
    });
  };

  return (
    <div className="space-y-2">
      <Label>Line items</Label>
      <div className="rounded-md border">
        <div className="grid grid-cols-12 gap-2 border-b bg-muted/40 px-2 py-2 text-xs font-medium">
          <div className="col-span-5">Product</div>
          <div className="col-span-2 text-right">Qty</div>
          <div className="col-span-2 text-right">Price</div>
          <div className="col-span-1 text-right">Tax%</div>
          <div className="col-span-1 text-right">Total</div>
          <div className="col-span-1" />
        </div>
        {items.map((l, i) => (
          <div key={i} className="grid grid-cols-12 items-center gap-2 border-b px-2 py-2 last:border-0">
            <div className="col-span-5">
              <Select value={l.product_id} onValueChange={(v) => onProduct(i, v)}>
                <SelectTrigger><SelectValue placeholder="Select product" /></SelectTrigger>
                <SelectContent>
                  {products.map((p) => (
                    <SelectItem key={p.id} value={p.id}>{p.sku} — {p.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Input className="col-span-2 text-right" type="number" min={0} value={l.qty} onChange={(e) => update(i, { qty: +e.target.value })} />
            <Input className="col-span-2 text-right" type="number" min={0} value={l.unit_price} onChange={(e) => update(i, { unit_price: +e.target.value })} />
            <Input className="col-span-1 text-right" type="number" min={0} value={l.tax_rate} onChange={(e) => update(i, { tax_rate: +e.target.value })} />
            <div className="col-span-1 text-right text-sm">{fmtMoney(lineSubtotal(l) + lineTax(l), sym)}</div>
            <Button size="icon" variant="ghost" className="col-span-1" onClick={() => setItems(items.filter((_, j) => j !== i))}>
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        ))}
      </div>
      <Button size="sm" variant="outline" onClick={() => setItems([...items, emptyLine()])}><Plus className="mr-1 h-4 w-4" /> Add row</Button>
    </div>
  );
}