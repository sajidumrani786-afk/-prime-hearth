import { useState, type ReactNode } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

export function CrudDialog({
  trigger,
  title,
  children,
  onSubmit,
  open: openProp,
  onOpenChange,
  submitLabel = "Save",
}: {
  trigger?: ReactNode;
  title: string;
  children: ReactNode;
  onSubmit: () => Promise<boolean | void>;
  open?: boolean;
  onOpenChange?: (v: boolean) => void;
  submitLabel?: string;
}) {
  const [internal, setInternal] = useState(false);
  const [busy, setBusy] = useState(false);
  const isControlled = openProp !== undefined;
  const open = isControlled ? openProp : internal;
  const setOpen = (v: boolean) => { isControlled ? onOpenChange?.(v) : setInternal(v); };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      {trigger && <DialogTrigger asChild>{trigger}</DialogTrigger>}
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader><DialogTitle>{title}</DialogTitle></DialogHeader>
        <div className="space-y-4">{children}</div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)} disabled={busy}>Cancel</Button>
          <Button
            onClick={async () => {
              setBusy(true);
              try {
                const r = await onSubmit();
                if (r !== false) setOpen(false);
              } finally { setBusy(false); }
            }}
            disabled={busy}
          >
            {busy ? "Saving..." : submitLabel}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}