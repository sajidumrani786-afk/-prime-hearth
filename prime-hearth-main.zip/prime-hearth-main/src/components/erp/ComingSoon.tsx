import { PageHeader } from "./PageHeader";
import { Card, CardContent } from "@/components/ui/card";

export function ComingSoon({ title, description }: { title: string; description?: string }) {
  return (
    <>
      <PageHeader title={title} description={description} />
      <Card><CardContent className="p-10 text-center text-muted-foreground">
        This module is being expanded. Core data is already captured via related workflows.
      </CardContent></Card>
    </>
  );
}